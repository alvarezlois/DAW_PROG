
package basket;

/**
 *
 * @author adrian alvarez lois
 */
public class Equipo implements Comparable<Equipo> {
    
// Atributos
    
    public String nombre; // nombre del equipo
    public String ciudad; // ciudad donde juega el equipo
    public String sponsor; // empresa que patrocina al equipo
    int victorias; // número de partidos ganados por el equipo
    int derrotas; // número de partidos perdidos por el equipo
    int partidos; // número total de partidos jugados por el equipo
    int puntosFavor; // número de puntos que anota cada equipo
    int puntosContra; // número de puntos que encaja cada equipo
    int puntos; // puntos totales del equipo
    int diferenciaPuntos; // número de puntos que mete un equipo menos los que encaja 
    
// Constructores

    public Equipo(String nombre) {
        this.nombre = nombre;
    }

    public Equipo(String nombre, String ciudad, String sponsor, int victorias, int derrotas, int puntosFavor, int puntosContra) {
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.sponsor = sponsor;
        this.partidos = victorias + derrotas;
        this.victorias = victorias;
        this.derrotas = derrotas;
        this.puntosFavor = puntosFavor;
        this.puntosContra = puntosContra;
        this.puntos = puntosFavor;
        this.diferenciaPuntos = puntosFavor - puntosContra;
    }
    
// Getters
    public String getNombre() {
        return nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getSponsor() {
        return sponsor;
    }

    public int getVictorias() {
        return victorias;
    }

    public int getDerrotas() {
        return derrotas;
    }
    
    public int getPuntos() {
        return puntos;
    }
    
    public int getPartidosJugados(){
        return getDerrotas() + getVictorias();
    }
    
    public int getDiferenciaPuntos(){
        return diferenciaPuntos;
    }

// Setters
    
     public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    public void setSponsor(String sponsor) {
        this.sponsor = sponsor;
    }
  
    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

    public void setPuntosFavor(int puntosFavor) {
        this.puntosFavor = puntosFavor;
    }

    public void setPuntosContra(int puntosContra) {
        this.puntosContra = puntosContra;
    }

  
    
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    // Dos equipos son iguales si sus nombres son iguales, o this.nombre comienza por el nombre del equipo pasado    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Equipo other = (Equipo) obj;
        String nom1 = this.nombre.toLowerCase();
        String nom2 = other.nombre.toLowerCase();
        return (nom1.equals(nom2) || nom1.startsWith(nom2));
    }
    
    // Devuelve una representación del Equipo
    @Override
    public String toString() {
        String texto;
        texto = "Nombre=" + nombre + "\n Ciudad=" + ciudad + "\n Sponsor=" + sponsor + "\n Nº de Victorias=" + victorias + "\n Nº de Derrotas=" + derrotas + "\n Partidos Jugados=" + partidos + "\n Puntos a Favor=" + puntosFavor + "\n Puntos en Contra=" + puntosContra + "\n Puntos Totales Anotados=" + puntos + "\n Diferencia de Puntos=" + diferenciaPuntos;
        return texto;
    }
    
            
    // Implementamos el método compareTo de Comparable, para poder comparar dos equipos.
    @Override
    public int compareTo(Equipo o) {
        return (puntos != o.getPuntos() ? puntos-o.getPuntos() : diferenciaPuntos-o.getDiferenciaPuntos());
    }
    
}
