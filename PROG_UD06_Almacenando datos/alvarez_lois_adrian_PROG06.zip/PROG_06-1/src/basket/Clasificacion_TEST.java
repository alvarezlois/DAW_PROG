
package basket;

import java.util.ArrayList;

/**
 *
 * @author adrian alvarez lois
 */
public class Clasificacion_TEST {
    //private Equipo equipos[]; // array para guardar los equipos
    ArrayList<Equipo> equipos = new ArrayList<Equipo>();
    private int numEquipos; // indicador del número de equipos de la liga
    static String nombreFichero = "clasificacion.dat"; // nombre del fichero
    
    // Constructor
    Clasificacion_TEST(int cantidad){
        //equipos = new Equipo[cantidad]; // creamos el array de tamaño la cantidad de equipos
        ArrayList<Equipo> equipos = new ArrayList<Equipo>(cantidad);
        numEquipos = 0; // inicialmente el numero de equipos es cero
    }
    
    // método para añadir equipos a la clasificación
    public void addEquipo(String nombre, String ciudad, String sponsor, int victorias, int derrotas, int puntosFavor, int puntosContra){
        // si el indicador del número de equipos de la liga es menor al número de equipos es posible añadirlos
        if (numEquipos < equipos.size()){
            Equipo newTeam = new Equipo(nombre);
            equipos.add(newTeam);
            numEquipos ++;
        }
    }
    
    // método para eliminar equipos de la clasificación
    public void removeEquipo(String nombre){
        // equipo que queremos buscar en el arraylist de equipos
        Equipo searchTeam = new Equipo(nombre);
        
        // recorremos la lista de equipos para buscarlo 
        for (int i = 0; i < equipos.size(); i++){
            // si el elquipo a buscar es igual a un equipo en una posición i de la lista lo borramos
            if (equipos.get(i).equals(searchTeam)){
                equipos.remove(i);
            }
        }
    }
    
    
    
    // método toString
    @Override
    public String toString() {
        return "Clasificacion{" + "equipos=" + equipos + '}';
    }
    
    
    
    
    
    
}
