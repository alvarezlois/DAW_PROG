
package basket;

/**
 *
 * @author adrian alvarez lois
 */
public class Basket {

    /**
     * @param args the command line arguments
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws ClassNotFoundException {
        
        Clasificacion liga1920 = new Clasificacion();
        
        liga1920.gestion();
        
  
    }
    
}
