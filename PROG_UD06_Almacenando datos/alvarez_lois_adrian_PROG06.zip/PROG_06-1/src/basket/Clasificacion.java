package basket;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author adrian alvarez lois
 */
public class Clasificacion implements Serializable {
    private int numEquipos; // indicador del número de equipos de la liga
    private Equipo equipos[] = new Equipo[numEquipos]; // array para guardar los equipos
    static String nombreFichero = "clasificacion.dat"; // nombre del fichero
    
    // Constructor

    public Clasificacion() {
        this.numEquipos = 18;
        this.equipos = new Equipo[numEquipos];
     
    }
    
    
    Clasificacion(int cantidad){
       equipos = new Equipo[cantidad]; // creamos el array de tamaño la cantidad de equipos
       numEquipos = 0; // inicialmente el numero de equipos es cero
    }
    
    // abre el fichero con la información de los equipos, en modo lectura, y carga
    // los datos en la tabla equipos
    public void loadClasificacion() throws ClassNotFoundException {
    
        ObjectInputStream in = null;
        this.equipos = new Equipo[0]; // tabla de tamaño 0
        
        try { // leemos los datos previamente almacenados en el fichero (de entrada)
            in = new ObjectInputStream(new FileInputStream(nombreFichero));
            equipos = (Equipo[]) (in.readObject());
        } catch (IOException e) {
            System.out.println(e);
        } finally { // nos aseguramos de que el archivo se cierra
            if (in != null){
                try {
                in.close();
                } catch (IOException ex) {
                System.out.println(ex);
                }
            }
        }
    }
    
    // vuelca el contenido de todos los equipos en un fichero de equipos
    public void saveClasificacion(){
        
        ObjectOutputStream out = null;
        
        try {
            out = new ObjectOutputStream(new FileOutputStream(nombreFichero));
            out.writeObject(equipos);
            out.close();
        } catch (IOException e) {
            System.out.println(e);
        } finally { // nos aseguramos de que el archivo se cierra
            if (out != null){
                try {
                out.close();
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
        }
    }
    
    // lee e inserta un nuevo equipo redimensionando la tabla con un tamaño +1
    public void addEquipo(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Datos del nuevo equipo");
        System.out.println("Nombre del equipo: ");
        String nom = sc.nextLine();
        System.out.println("Ciudad sede del equipo: ");
        String city = sc.nextLine();
        System.out.println("Patrocinador del equipo: ");
        String patro = sc.nextLine();
        System.out.println("Número de partidos ganados: ");
        int vic = sc.nextInt();
        System.out.println("Número de partidos perdidos: ");
        int derr = sc.nextInt();
        System.out.println("Cantidad de puntos anotados: ");
        int fav = sc.nextInt();
        System.out.println("Cantidad de puntos encajados: ");
        int cont = sc.nextInt();
        
        // redimensionamos el tamaño del array para poder añadir el nuevo equipo
        equipos = Arrays.copyOf(equipos, equipos.length + 1);
        
        // insertamos el nuevo equipo en la última posición del array equipos
        equipos[equipos.length -1] = new Equipo(nom, city, patro, vic, derr, fav, cont);
        }
    
    // método que busca un equipo en el array y nos devuelve la posición 
    public int buscar(String nom){
        int pos = 0;
        nom = nom.toLowerCase();
        for (int i = 0; i < equipos.length; i++){
            if (nom == equipos[i].nombre.toLowerCase()){
            pos = i;
            }
        }
        return pos;
    }
    
    
    // Elimina el equipo, si existe, con identificador nombre
    public void removeEquipo(String nom){
        int pos = buscar(nom);
        if (pos == -1){
            System.out.println("El equipo no existe.");
        } else { // machamos el equipo a borrar (indice pos) con el último
            equipos[pos] = equipos[equipos.length -1]; 
            // trabajamos con tablas completas: redimensionamos la tabla a un tamaño -1
            equipos = Arrays.copyOf(equipos, equipos.length - 1);
        }
    }
    
    // muestra las opciones del menú, lee una opción correcta y la devuelve
    public int menu(){
        Scanner sc = new Scanner(System.in);
        int opc; // opción del menú
        
        // mostramos las opciones
        System.out.println("1. Añadir equipo.");
        System.out.println("2. Mostrar clasificación.");
        System.out.println("3. Eliminar equipo.");
        System.out.println("4. Guardar clasificación.");
        System.out.println("5. Cargar clasificación.");
        System.out.println("6. Salir.");
        
        do {
            System.out.print("Escriba una opción: ");
            opc = sc.nextInt();
        } while (opc < 1 || opc > 6);
        
        return opc;
    }
    
    // Comienza la gestión de la clasificación (añadir equipo, mostrar clasif, borrar equipo, guardar clasif, cargar clasif, salir)
    public void gestion() throws ClassNotFoundException{
        Scanner sc = new Scanner(System.in);
        int opcion;
        do {
            opcion = menu();
            switch (opcion){
                case 1: // Añadir equipo
                    addEquipo();
                    break;
                
                case 2: // Mostrar clasificacion. Si no hay datos no muestra nada
                    System.out.println("Clasificación:\n" + Arrays.toString(equipos));
                    break;
                
                case 3: // Borrar equipo
                    System.out.println("Nombre del equipo a eliminar: ");
                    String nom = sc.nextLine();
                    removeEquipo(nom);
                    break;
                    
                case 4: // Guardar clasificación
                    saveClasificacion();
                    break;
                    
                case 5: // Carga clasificación
                    loadClasificacion();
                    break;
              
            }
        
        } while (opcion != 6);
    
    }
    
    
    
}
