
package net.iessanclemente.naipes;
import static net.iessanclemente.naipes.Naipe.*;
/**
 *
 * @author adrian alvarez lois
 */
public final class BarajaInglesa extends Baraja {

    // ATRIBUTOS
    public static int NUM_CARTAS = 52;
    boolean comodines = false;
    
    // CONSTRUCTOR
    public BarajaInglesa(){
    super(NUM_CARTAS);
    iniciar();
    }
    
    public BarajaInglesa(boolean comodines){
        super(NUM_CARTAS);
        if (comodines){
            NUM_CARTAS = 54;
        }
        iniciar();
    }
    
    
    // GETTER
    public boolean hasComodines() {
        return comodines;
    }
    
    // SETTER
    public void setComodines(boolean comodines) {
        this.comodines = comodines;
    }
    
    // MÉTODO iniciar
    public void iniciar(){
        int posicion = 0;
        for (int j = 1; j < (NUM_CARTAS/NUM_PALOS); j++){
            setCarta(new Naipe(j, DIAMANTES), posicion++);
            setCarta(new Naipe(j, PICAS), posicion++);
            setCarta(new Naipe(j, TREBOLES), posicion++);
            setCarta(new Naipe(j, CORAZONES), posicion++);        
        }
        if (comodines){
            setCarta(new Naipe(JOKER_R), posicion++);
            setCarta(new Naipe(JOKER_B), posicion++);
        }
    
    }
    
    
    // MÉTODO toString
    @Override
    public String toString() {
        //StringBuilder listado = new StringBuilder();
        String listado = "";
        Naipe[] cartas = getCartas();
        for (int x = 0; x<= cartas.length; x++){
            listado = listado + cartas[x];
        }
        return listado;
    }
    
}
