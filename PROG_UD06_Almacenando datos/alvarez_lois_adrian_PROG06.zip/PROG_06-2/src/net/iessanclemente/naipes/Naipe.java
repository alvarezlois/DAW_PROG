
package net.iessanclemente.naipes;

/**
 *
 * @author adrian alvarez lois
 */
public class Naipe implements Comparable<Naipe>{
    
        
    // ENUMERACIÓN 
    /*
    Los tipos enumerados sirven para definir grupos de constantes como valores posibles de una variable.
    */
    public enum Palo {
        OROS(1), COPAS(2), BASTOS(3), ESPADAS(4);
        // Atributo valor
        private final int valor;
        // Constructor para Palo
        Palo(int n){
        this.valor = n;
        }
        // Métido getValor(), que devuelve el valor
        public int getValor(){
        return valor;
        } 
    }
      
    // creo un array con los palos de enum al que le llamo listado
    static Palo listado[] = Palo.values();
    
    // Método isValidPalo, que recoge un entero y nos dice si dicho entero está en la lista
        public static boolean isValidPalo(int x){
        boolean comprobacion = false;
        for(int i = 0; i < listado.length; i++){
            if(x == listado[i].getValor()){
            comprobacion = true;
            }
        }
        return comprobacion;
        }
        
    
        
        
    // ATRIBUTOS
    private  int numero;
    private int palo;
    private boolean tapada;    
    
    // palos baraja francesa
    public static final int NUM_PALOS = 4;
    public static final int DIAMANTES = -1;
    public static final int PICAS = -2;
    public static final int TREBOLES = -3;
    public static final int CORAZONES = -4;
    public static final int JOKER_R = 0;
    public static final int JOKER_B = -5;
    // fuguras 
    public static final int JACK = 11;
    public static final int QUEEN = 12;
    public static final int KING = 13;
    public static final int JOKER = 0;
 
    
     // CONSTRUCTORES
    public Naipe(int numero, int palo) {
        this.numero = numero;
        this.palo = palo;
         try {
            if (numero < 1 || numero > 12){
            throw new IsNotANaipeNumberException(404, numero);
            } 
        } catch (IsNotANaipeNumberException ex){
            System.out.println(ex.getMessage());
        }
    }

    public Naipe(int palo) {
        this.palo = palo;
        this.numero = JOKER;
        
    }

    // GETTERS
    public int getNumero() {
        return numero;
    }

    public int getPalo() {
        return palo;
    }

    public boolean isTapada() {
        return tapada;
    }
        
    // SETTERS
    public void setNumero(int numero) {
        this.numero = numero;
        try {
            if (numero < 1 || numero > 12){
            throw new IsNotANaipeNumberException(404, numero);
            } 
        } catch (IsNotANaipeNumberException ex){
            System.out.println(ex.getMessage());
        }
    }

    public void setPalo(int palo) {
        this.palo = palo;
    }

    public void setTapada(boolean tapada) {
        this.tapada = tapada;
    }
 
   // MÉTODO getPauAsString
   public String getPauAsString(){
       String resultado = "";
       switch(palo){
           case DIAMANTES:
               resultado = "diamantes";
               break;
           case PICAS:
               resultado = "picas";
               break;
           case TREBOLES:
               resultado = "tréboles";
               break;
           case CORAZONES:
               resultado = "corazones";
               break;
           case JOKER_R:
               resultado = "joker rojo";
               break;
            case JOKER_B:
               resultado = "joker negro";  
               break;
       }
       return resultado;
   }
   
   // MÉTODO getNumAsString
   public String getNumeroString(){
       String resultado = "";
       switch(numero){
           case 1:
               resultado = "as";
               break;
           case 11:
               resultado = "jack";
               break;
           case 12:
               resultado = "reina";
               break;
           case 13:
               resultado = "rey";
               break;
           case JOKER:
               resultado = "joker";
               break;
            case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:
                return String.valueOf(numero);
                
              
       }
       return resultado;
   }
   // MÉTODO toString
    @Override
    public String toString() {
       return "Naipe{" + "numero=" + numero + ", palo=" + palo + ", tapada=" + tapada + '}';
   }
   // MÉTODO compareTo
    @Override
    public int compareTo(Naipe o) {
        return (palo != o.getPalo() ? palo-o.getPalo() : numero-o.getNumero());
    }
   
   
    
    
    
    
    
}
