
package net.iessanclemente.naipes;

import java.util.Scanner;
/**
 *
 * @author adrian alvarez lois
 */
public class AppPROOG_0405 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Quieres usar comodines? SI: 1 / NO: 0");
        
        int comodines = sc.nextInt();
        
        if (comodines == 1){
            BarajaInglesa cards = new BarajaInglesa(true);
        }else{ 
            BarajaInglesa cards = new BarajaInglesa(); 
        }
        
        Naipe n = new Naipe(99, 3);
        
        
    }
    
}
