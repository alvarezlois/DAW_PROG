
package net.iessanclemente.naipes;

/**
 *
 * @author adrian alvarez lois
 */
public class IsNotANaipeNumberException extends Exception {
    
    private final int codigoError;
    int numNaipeMalo;
    
    public IsNotANaipeNumberException(int codigoError, int numNaipe){
        super();
        this.codigoError=codigoError;
        this.numNaipeMalo=numNaipe;
    }
    
      @Override
    public String getMessage(){
         
        String mensaje="";
         
        switch(codigoError){
            case 404:
                mensaje="El número " + numNaipeMalo + "no es válido" ;
                break;
        }
         
        return mensaje;
         
    }

    @Override
    public String toString() {
        return "IsNotANaipeNumberException{" + getMessage() + '}';
    }
    
    
    
}
