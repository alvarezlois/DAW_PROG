
package net.iessanclemente.naipes;

import java.util.Random;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.*;

/**
 *
 * @author adrian alvarez lois
 */
public  abstract class Baraja {

    // ATRIBUTOS
    private static Naipe[] cartas;
    static final Random ALEATORIO = new Random();
    static int NUM_INTERCAMBIOS = 1500;
    /**
     *
     */
    public static final String ARCHIVO = "baraja.dat";
    Path p = Paths.get(System.getProperty("user.dir"), ARCHIVO);
       
    // CONSTRUCTOR
    public Baraja(int size) {
        this.cartas = new Naipe[size];
    }
    
    public Baraja(boolean comodines) {
        if(comodines){
        this.cartas = new Naipe[54];
        }
        this.cartas = new Naipe[52];
    }
    
    // método que devuelve verdadero o falso si puede o no guardar la baraja en el archivo
    public boolean saveBaraja(){
        boolean exito = true;
        ObjectOutputStream out = null;
        
        try {
            out = new ObjectOutputStream(new FileOutputStream(ARCHIVO));
            out.writeObject(cartas);
            out.close();
            exito = true;
        } catch (IOException e) {
            System.out.println(e);
            exito = false;
        } finally { // nos aseguramos de que el archivo se cierra
            if (out != null){
                try {
                out.close();
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
        }
        return exito;
    }
    
    // cargar las barajas del archivo baraja.dat, guardado en el directorio de la aplicación.
    public static void loadBaraja() throws ClassNotFoundException {
    
        ObjectInputStream in = null;
        Baraja.cartas = new Naipe[0]; // tabla de tamaño 0
        
        try { // leemos los datos previamente almacenados en el fichero (de entrada)
            in = new ObjectInputStream(new FileInputStream(ARCHIVO));
            cartas = (Naipe[]) (in.readObject());
        } catch (IOException e) {
            System.out.println(e);
        } finally { // nos aseguramos de que el archivo se cierra
            if (in != null){
                try {
                in.close();
                } catch (IOException ex) {
                System.out.println(ex);
                }
            }
        }
    }
    
    // GETTER
    public Naipe[] getCartas() {
        return cartas;
    }
    
    // SETTER
    public void setCartas(Naipe[] cartas) {
        this.cartas = cartas;
    }
          
    // MÉTODO SetCarta
    public void setCarta(Naipe carta, int indice) {
        cartas[indice] = carta;
    }
    
    // MÉTODO getNumCartasBaraja
    public int getNumCartasBaraja(){
    return cartas.length;
    }
    
    // MÉTODO getNumCarta
    public int getNumCartas(){
        int contador = 0;
        for (int i=0; i<cartas.length; i++){
            if (cartas[i] != null){
                contador ++;
            }
        }
        return contador ;
    }
    
    // MÉTODO retirarCarta
    public Naipe retirarCarta(){
    for (int i=cartas.length-1; i>=cartas.length; i--){
        if (cartas[i] != null){
        Naipe n = cartas[i];
        cartas[i] = null;
        return n;
        }
    }
    return null;
    }
    
    // MÉTODO addCarta
    public void addCarta(Naipe carta){
        for (int w = 0; w < cartas.length; w++){
            if (cartas[w] == null){
            cartas[w] = carta;
             }
        }  
    }
    
    // MÉTODO barajar
    public void barajar(){
        // Bucle que intercambia 2 cartas 1500 veces
        for(int z = 0; z <= NUM_INTERCAMBIOS; z++){
        // generamos 2 índices aleatorios
        int indexA = ALEATORIO.nextInt() * cartas.length + 1;
        int indexB = ALEATORIO.nextInt() * cartas.length + 1;
        // nos quedamos con los naipes que están en los indices aleatorios
        Naipe naipeA = cartas[indexA];
        Naipe naipeB = cartas[indexB];
        // los intercambiamos
        naipeA = cartas[indexB];
        naipeB = cartas[indexA];
        }
    }
    
    
    
    // MÉTODO toString
    @Override
    public abstract String toString();
    
    
    
}
