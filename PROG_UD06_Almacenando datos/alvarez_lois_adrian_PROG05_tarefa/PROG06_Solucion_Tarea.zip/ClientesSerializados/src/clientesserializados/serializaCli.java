package clientesserializados;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.* ;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;



 // José Javier Bermúdez Hernández, Noviembre 2010


public class serializaCli {

    private static String ruta = "C:\\clientes.dat" ;

    private static int leeOpcion() {
        
        int nOpcion = 10 ;

        try {
            BufferedReader lect = new BufferedReader(new InputStreamReader(System.in));

            // Leer desde teclado la opción
            String cOpcion = lect.readLine();

            nOpcion = Integer.parseInt(cOpcion) ;
         } catch(NumberFormatException e) {
              System.err.println("NO ES UN NÚMERO VÁLIDO: Vuelve a intentarlo.");}
           catch(IOException ex) {
               System.err.println("NO ES UN NÚMERO VÁLIDO: Vuelve a intentarlo.");}
           catch(Exception exc) {
               System.err.println("NO ES UN NÚMERO VÁLIDO: Vuelve a intentarlo.");}

        return (nOpcion) ;
    }


    public static void main(String[] args) throws FileNotFoundException, IOException {
        boolean seguir = true ;

        while (seguir) {
             
            System.out.println("Selecciona una opción:");
            
            System.out.println("[1] Añadir cliente.");
            System.out.println("[2] Listar clientes.");
            System.out.println("[3] Buscar clientes.");
            System.out.println("[4] Borrar cliente.");
            System.out.println("[5] Borrar fichero de clientes completamente..");
            System.out.println("[6] Salir.");

            System.out.println("Escriba la selección: ");
            int selec = 0 ;
            selec  = leeOpcion() ;

            // Según la selección que se haya realizado
            switch (selec){
                case 1: agregaCliente();
                    break;
                case 2: listaClientes();
                    break;
                case 3: buscaCliente() ;
                    break;
                case 4: borrarCliente();
                    break;
                case 5: borrarFichero();
                    break;
                case 6:
                    seguir = false ;
                    break ;
                default:
                    System.out.println("Selecciona una opción válida.");
            } 
        }
    }

    private static void borrarFichero() {
        // Attempt to delete it
        File f = new File(ruta);
        boolean success = f.delete();
        if (success)
            System.out.println("Borrado ok") ;
        else
            System.out.println("Borradno no posible") ;
    }

    // Borrar cliente
    private static void borrarCliente() {
        Clientes cliente = null ;
        List listaContinente;
        listaContinente = new ArrayList();
        boolean salir = false ;
        FileInputStream fiCliLec ;
        ObjectInputStream fluent ;

        try {
            BufferedReader lect = new BufferedReader(new InputStreamReader(System.in));
            
            // Leer desde teclado el nif
            System.out.println("Escribe nif del cliente a borrar");
            String elNif = lect.readLine();

            fiCliLec = new FileInputStream( ruta );
            fluent = new ObjectInputStream(fiCliLec);

            do {
                // Leer el objeto del fichero
                try {
                    cliente = (Clientes) fluent.readObject();
                } catch (Exception ex) {
                    salir = true ;
                     //System.out.println( "Ojo que te pillé" + ex.getCause() ) ;
                }

                if (cliente != null)  {        
                    // si el nif se corresponde con el que buscamos
                    if (cliente.getNif().equals(elNif))
                        System.out.println("Cliente a eliminar encontrado.");
                    else
                        // Añadirlo a la lista de los conservables.
                        if (salir == false)
                           listaContinente.add(cliente) ;
                }
                else 
                    salir = true ;
                
            } while ((cliente != null) && (salir == false)) ;

            // Cerrar
            fiCliLec.close() ;
            fluent.close();

            // Escribir todos menos el que queremos a un fichero
            escribeLista(listaContinente) ;

           // if (listaContinente.isEmpty() )
             //   System.out.println("La lista está vacía") ;
            //else
              //  System.out.println("La lista no está vacía") ;


        } catch (FileNotFoundException e) {
            System.out.println( e.getMessage() ) ;
        } catch (Exception ex) {
            System.out.println( ex.getMessage() ) ;
            System.out.println( "Capturada" ) ;
        }finally {
            // Actividades que siempre ocurren
     
        }

    }

   

    // escribir la lista
    private static void escribeLista(List lista){
        Iterator <Clientes> cli = lista.iterator() ;
       
        ObjectOutputStream flusal ;

        try {
            // Crear fichero temporal
            File temp = File.createTempFile("tempo", ".tmp" );
            FileOutputStream ficlisal = new FileOutputStream(temp);
            // Mientras haya clientes
            while (cli.hasNext()){
                // Obtenemos el cliente
                Clientes elCliente = cli.next() ;

                //System.out.println( "And the names is: " + elCliente.getNombre() );
                flusal = new ObjectOutputStream(ficlisal);

                //Ahora se escribe en el fichero
                if (flusal != null){
                    flusal.writeObject(elCliente);
                    System.out.println( "Se escribe en el temporal: " + elCliente.getNombre() );
                }
            }
            // Cerrar
            ficlisal.close();

            //Borrar el fichero de clientes actual, el malo ahora
            borrarFichero() ;

            // Rrenombrar el fichero temporal como el clientes.dat
            File nuevoF = new File(ruta);
            boolean correcto = temp.renameTo(nuevoF);
            if (correcto)
                System.out.println("El renombrado a Clientes.dat ha sido correcto");
            else
                System.out.println("El renombrado no se ha podido realizar");
                      
        } catch (IOException ex) {
                System.out.println("Hubo un problema escribiendo al fichero temporal.");
            }
    }

    // Añadir cliente
    private static void agregaCliente() {
        
        BufferedReader lectura = new BufferedReader(new InputStreamReader(System.in));
        FileOutputStream ficli ;
        ObjectOutputStream flusal ;
        try {
            String nombre;
            String telefono;
            String direccion ;
            String nif ;

            // Leer desde teclado el nif
            System.out.println("Escribe nif del cliente");
            nif = lectura.readLine();
            

            // Leer desde teclado el nombre
            System.out.println("Escribe nombre del cliente");
            nombre = lectura.readLine();
            // Ajustar el tamaño de la cadena a 10 caracteres
            nombre = ajustaTexto(nombre) ;

            // Leer desde teclado el telefono
            System.out.println("Escribe teléfono del cliente");
            telefono = lectura.readLine();
            // Ajustar el tamaño de la cadena a 10 caracteres
            telefono = ajustaTexto(telefono) ;

            // Leer desde teclado la dirección
            System.out.println("Escribe la dirección del cliente");
            direccion = lectura.readLine();
            // Ajustar el tamaño de la cadena a 10 caracteres
            direccion = ajustaTexto(direccion) ;

            // Leer desde teclado la deuda
            System.out.println("Escribe la deuda");
            String varDeuda = lectura.readLine();
            
            // Creamos un nuevo objeto cliente
            Clientes nuevoCli = new Clientes() ;
            nuevoCli.setNif(nif) ;
            nuevoCli.setNombre(nombre) ;
            nuevoCli.setTelefono(telefono) ;
            nuevoCli.setDireccion(direccion) ;
            nuevoCli.setDeuda(varDeuda) ;

            // Guardar en el fichero el nuevo cliente
            // Primero se abre el fichero
            ficli = new FileOutputStream( ruta, true );

            // Si el fichero ya tenía registros
            if (tieneRegistros())
                // Uso esta redefinición de la clase para
                // evitar que escriba datos de la cabecera que corromperían
                // la posterior lectura del fichero
                flusal = new MiObjectOutputStream(ficli);
            else
                flusal = new ObjectOutputStream(ficli);

            //Ahora se escribe
            if (flusal != null)
                flusal.writeObject(nuevoCli);

            // Cerrar
            flusal.close() ;
            ficli.close() ;
         
        } catch (IOException ex) {
            Logger.getLogger(serializaCli.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    // Función para ajustar la cadena a tamaño 10 de longitud
    private static String ajustaTexto(String cadena){
         if (cadena.length() < 10)
                return (String.format("%1$-10s", cadena)) ;
         else
                return ( cadena.substring(0, 10)) ;
    }

    public static boolean esNumero (String cadena) {
        try {
            Float.parseFloat(cadena);
            return true;
        } catch (NumberFormatException nfe){
            return false;
        }
    }

    private static void listaClientes() throws FileNotFoundException, IOException {

        File f = new File(ruta);
        boolean existe = f.exists() ;
        if (existe) {

        Clientes cliente = null ;
  
        FileInputStream fiCliLec ;
        ObjectInputStream fluent;

        fiCliLec = new FileInputStream( ruta );
        fluent = new ObjectInputStream(fiCliLec);
        try {

        
          try {
            
            
            do {
                // Leer el objeto del fichero
                cliente = (Clientes) fluent.readObject();
                System.out.println(cliente.getNif());
                System.out.println(cliente.getNombre());
                System.out.println(cliente.getDireccion());
                System.out.println(cliente.getTelefono());
                System.out.println(cliente.getDeuda());
                
            } while (cliente != null) ;

            fiCliLec.close();
            fluent.close();

        } catch (FileNotFoundException e) {
            System.out.println( e.getCause() ) ;
        } catch (Exception ex) {
            System.out.println( ex.getMessage() ) ;}
      } catch (Exception e) {
            System.out.println( e.getCause() ) ;
      } finally {
           fiCliLec.close();
           fluent.close();
             }
}
        else
            System.out.println( "El fichero no existe." ) ;
    }

    // Comprueba si hay algún registro en el fichero
    private static boolean tieneRegistros(){
        boolean tiene = false ;
        FileInputStream fiCliLec ;
        ObjectInputStream fluent;
        Clientes cliente = null ;
        try {
            fiCliLec = new FileInputStream( ruta );
            fluent = new ObjectInputStream(fiCliLec);

            // Leer el objeto del fichero
            cliente = (Clientes) fluent.readObject();

            if (cliente != null)
                tiene = true ;
            fiCliLec.close();
            fluent.close();
        } catch (FileNotFoundException e) {
            System.out.println( "Error: " + e.getMessage() ) ;
        } catch (Exception ex) {
            System.out.println( "Capturada excepción en tieneRegistros()" ) ;}
        finally {
          // fiCliLec.close();
          //  fluent.close();
             }

        return(tiene) ;
    }


    // Borrar cliente
    private static void buscaCliente() {
        Clientes cliente = null ;
        boolean salir = false ;
        FileInputStream fiCliLec ;
        ObjectInputStream fluent ;

        try {
            BufferedReader lect = new BufferedReader(new InputStreamReader(System.in));

            // Leer desde teclado el nif
            System.out.println("Escribe nif del cliente a buscar");
            String elNif = lect.readLine();

            fiCliLec = new FileInputStream( ruta );
            fluent = new ObjectInputStream(fiCliLec);

            do {
                // Leer el objeto del fichero
                try {
                    cliente = (Clientes) fluent.readObject();
                } catch (Exception ex) {
                    salir = true ;
                }
                // Si hemos leído un objeto
                if (cliente != null)  {
                    // si el nif se corresponde con el que buscamos
                    if (cliente.getNif().equals(elNif)){
                        System.out.println("Cliente encontrado.");
                        System.out.println(cliente.getNif());
                        System.out.println(cliente.getNombre());
                        System.out.println(cliente.getDireccion());
                        System.out.println(cliente.getTelefono());
                        System.out.println(cliente.getDeuda());
                    }
                }
                else
                    salir = true ;

            } while ((cliente != null) && (salir == false)) ;

            // Cerrar
            fiCliLec.close() ;
            fluent.close();
        } catch (FileNotFoundException e) {
            System.out.println( e.getMessage() ) ;
        } catch (Exception ex) {
            System.out.println( ex.getMessage() ) ;
            System.out.println( "Capturada" ) ;
        }finally {
            // Actividades que siempre ocurren
        }
    }

}