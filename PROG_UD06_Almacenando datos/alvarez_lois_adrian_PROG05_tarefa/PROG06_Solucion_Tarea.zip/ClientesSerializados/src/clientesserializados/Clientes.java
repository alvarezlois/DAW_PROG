package clientesserializados;

import java.io.Serializable;

// José Javier Bermúdez Hernández, Octubre 2010

public class Clientes implements Serializable {

    private String nif ;
    private String nombre ;
    private String telefono ;
    private String direccion ;
    private String deuda ;


    public Clientes() {
    }

    public void setNif(String elnif) {
        nif = elnif ;
    }
    public void setNombre(String nom) {
        nombre = nom ;
    }
    public void setTelefono(String tlf) {
        telefono = tlf ;
    }
    public void setDireccion(String dir) {
        direccion = dir ;
    }
    public void setDeuda(String money) {
        deuda = money ;
    }

    public String getNif() {
        return nif ;
    }
    public String getNombre() {
        return nombre ;
    }
    public String getTelefono() {
        return telefono ;
    }
    public String getDireccion() {
        return direccion ;
    }
    public String getDeuda() {
        return deuda ;
    }
}

