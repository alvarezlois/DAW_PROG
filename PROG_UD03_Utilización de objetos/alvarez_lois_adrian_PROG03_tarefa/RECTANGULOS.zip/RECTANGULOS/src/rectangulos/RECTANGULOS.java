/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangulos;

/**
 *
 * @author adrian
 */
public class RECTANGULOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rectangulo r1 = new Rectangulo(0, 0, 2, 9);
        Rectangulo r2 = new Rectangulo(2, 4, 2, 3);
        
        Rectangulo inter = new Rectangulo();
        Rectangulo inter2 = new Rectangulo();
        inter = inter.interseccion(r1, r2);
        System.out.println(inter.xIni);
        inter2 = r1.interseccion2(r2);
        System.out.println(inter2.xIni);
        
        
        
        Rectangulo movido = new Rectangulo();
        r2 = r2.mover(2, 3);
        System.out.println(r2.xIni);
        r1 = r1.mover(2, 5);
        
        Rectangulo r3 = new Rectangulo();
        Rectangulo r4 = new Rectangulo();
        r3 = r1.union(r2);
        System.out.println(r3.alto);
        
        Rectangulo oRect = new Rectangulo();
        oRect.ancho = 10;
        oRect.alto = 20;
        System.out.println("A área é " + oRect.getArea());

        
    }
    
}
