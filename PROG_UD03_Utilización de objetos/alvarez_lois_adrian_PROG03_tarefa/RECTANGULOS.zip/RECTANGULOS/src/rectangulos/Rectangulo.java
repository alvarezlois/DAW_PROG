/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectangulos;

/**
 *
 * @author adrian
 */
public class Rectangulo {
   int ancho;
   int alto;
   int xIni;
   int yIni;
   int yFin;
   int xFin;

   
    // constructor que non recolle valores
    public Rectangulo(){
        alto = 1; // 1 é o valor mínimo aceptable dos atributos
        ancho = 1; // non pode ser 0 porque se non non existe o rectángulo
    }
    
    // constructor ao que se lle pasan as coordenadas dos vertices
    public Rectangulo (int xIni, int yIni, int xFin, int yFin){
        this.xIni = xIni;
        this.yIni = yIni;
        this.xFin = xFin;
        this.yFin = yFin;
        this.alto = (yFin - yIni);
        this.ancho = (xFin - xIni);
    }
    // constructor ao que se lle pasa a dimensión (alto , ancho)
    // supoñendo como vértice de orixe o (0,0)
    public Rectangulo (int alto, int ancho){
        this.xIni = 0;
        this.yIni = 0;
        this.xFin = ancho;
        this.yFin = alto;
        this.alto = alto;
        this.ancho = ancho;
        
    }
    
     // getters
     public int getXini(){
        return xIni;
     }
     public int getXfin(){
        return xFin;
    } 
    public int getYini(){
        return xIni;
    }
     public int getYfin(){
        return yFin;
    }
    public int getAncho(){
        return ancho;
    }
    public int getAlto(){
        return alto;
    }
    
    // getArea (calcula a área)
    /* No main podería ser:
    Rectangulo r = new Rectangulo();
    int area;
    area = r.getArea();
    */
    public int getArea(){
        return (getAncho() * getAlto());
    }
    
    /*  
    // método que contrue un rectángulo a partir de outro (copia de un rectangulo)
    public Rectangulo (Rectangulo r){
        this.alto = r.alto;
        this.ancho = r.ancho;
    }
    */
    
    // método que move un rectángulo x unidades en horizontal e y unidades en vertical
        /*
        Devolve outro rectángulo que non é mais que unha copia do incial ao que se lle suman
        os valores X e Y aos seus 2 vértices.
        No main podería ser:
        Rectangulo r = new Rectangulo();
        r = r.mover(2, 2);
         */
    public Rectangulo mover(int x, int y){
        Rectangulo movido = new Rectangulo();
        movido.xIni = getXini() + x;
        movido.yIni = getYini() + y;
        movido.xFin = getXfin() + x;
        movido.yFin = getYfin() + y;
        movido.ancho = (xFin - xIni);
        movido.alto = (yFin - yIni);
        return movido;
    }       
 
    // método que calcula a intersección entre 2 rectángulos 
        /*
        A intersección é un novo rectángulo que ten como vértice
        inferior o vértice inferior do rectangulo 2 e o vértice superior
        é o vértice superior do rectangulo 1.
        No main poderiamos usalo así:
        Rectangulo inter = new Rectangulo();
        inter = inter.interseccion2(r1, r2);
         */
    
    public Rectangulo interseccion(Rectangulo r1, Rectangulo r2){
        Rectangulo intersecado = new Rectangulo();
        intersecado.xIni = r2.getXini();
        intersecado.yIni = r2.getYini();
        intersecado.xFin = r1.getXfin();
        intersecado.yFin = r1.getYfin();
        intersecado.ancho = (xFin - xIni);
        intersecado.alto = (yFin - yIni);
        return intersecado;
    }
    // este método para calcular as interseccions mola mais!!!!!!!!!!!!!!!!!!
        /*
        A este método só se lle pasa como parámetro un rectángulo.
        No main poderiamos usalo así:
        Rectangulo inter2 = new Rectangulo();
        inter2 = r1.interseccion2(r2);
        */
        
      public Rectangulo interseccion2(Rectangulo r){
        Rectangulo intersecado = new Rectangulo();
        intersecado.xIni = r.getXini();
        intersecado.yIni = r.getYini();
        intersecado.xFin = getXfin();
        intersecado.yFin = getYfin();
        intersecado.ancho = (xFin - xIni);
        intersecado.alto = (yFin - yIni);
        return intersecado;
    }
    
    // método que calcula a unión entre 2 rectángulos
        /*
        A unión de 2 rectángulos é outro rectángulo que supoño que ten o vértice incial
        onde o vértice inicial do primeiro rectángulo e o vértice final onde o do segundo
        */
      
        public Rectangulo union(Rectangulo r){
        Rectangulo unido = new Rectangulo();
        unido.xIni = getXini();
        unido.yIni = getYini();
        unido.xFin = r.getXfin();
        unido.yFin = r.getYfin();
        unido.ancho = (xFin - xIni);
        unido.alto = (yFin - yIni);
        return unido;
        }
   // método para ver se un punto está dentro dun rectangulo
        /*
        Para comprobar isto temos que ver pasarlle ao método unhas
        cordenadas (x, y) dun punto e ver se o seu valor está dentro dos vértices.
        É dicir se a cordenada x do punto a consultar é maior ou igual que xIni pero 
        tamén igual ou menor que xFin. E coas ordenadas igual.
        Usaremos un booleano como o que nos vai a devolver o método.
        */
        public boolean estaDentro(int dx, int dy){
            boolean inside = false;
            xIni = getXini();
            yIni = getYini();
            xFin = getXfin();
            yFin = getYfin();
            
            if((xIni <= dx) && (yIni <= dy) && (xFin >= dx) && (yFin >= dy)){
            inside = true;
            }
            return inside;
        }
          public String toString(){
            String texto="Vértice Ini: "+xIni+","+yIni+"\n"+
                "Vértice Ini: "+xIni+","+yIni+"\n"+
                "Ancho: "+ancho+"\n"+
                "Alto: "+alto;
            return texto;
        }
                    
      
}


