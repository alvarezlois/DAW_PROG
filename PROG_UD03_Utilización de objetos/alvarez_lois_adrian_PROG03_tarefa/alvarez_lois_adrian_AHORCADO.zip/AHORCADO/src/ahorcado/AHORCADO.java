/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ahorcado;

import javax.swing.JOptionPane;

/**
 *
 * @author adrian
 */
public class AHORCADO {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        Jugador jugador = new Jugador();
        Palabra palabra = new Palabra();
        String nomeXogador;
        String palabraIncognita;
        String letra;
        String palabraAcertada;
        String mensaxe="";
        int erros = 0;
        int errosTope;
        int acertos;
        boolean adivinado = false;
        
        
        // Invocamos o método que nos pide e mostra o nome do xogador
         nomeXogador = jugador.pedirNomeXogador();
         System.out.println("O nombre do xogador é: " + nomeXogador);
         
         // Invocamos o método que nos pide a palabra a buscar
         palabraIncognita = palabra.pedirIncognita();
         
         // Invocamos o método que contrue a palabra acertada (ao principio do xogo só mostrará caracteres)
         int lonxitude = palabra.palabraIncognita.length();
         palabraAcertada = palabra.iniciarPalabra(lonxitude);
         System.out.println("Palabra a adivinar: " + palabraAcertada);
         // Fixamos o valor do máximo de erros permitidos
         errosTope = (lonxitude + 3);
         System.out.println("Tes un máximo de " + errosTope + " erros permitidos.");
         
         
         // Comezamos o xogo
         do {
         letra = JOptionPane.showInputDialog("Introduce unha letra:"); // pedimos unha letra
         letra = letra.toLowerCase(); // pasamos a letra a minusculas porque java diferencia entre may e min.
                
         // comprobamos se acertamos algunha letra e actualizamos os ??? e poñemos a letra no seu sitio.
         palabraAcertada = palabra.comprobarLetra(palabraIncognita, letra, palabraAcertada);
          // contabilizamos os acertos e actualizamos o número de erros.
         acertos = jugador.contarAcertos(palabraIncognita, letra);
         if (acertos == 0){ //se non acertamos
            erros++; //sumamos 1 aos erros
            }
        // mostramos toda a información
         mensaxe += "A palabra ten " + acertos + " " + "'" + letra.toUpperCase() + "'" + " na palabra.";
         System.out.println(mensaxe);
         System.out.println("Quédanche " + (errosTope - erros) + " erros permitidos.");
         System.out.println("Palabra a adivinar: " + palabraAcertada);
         
        // reseteamos a mensaxe
        mensaxe = "";
         
        // comprobamos se adiviñamos a palabra. Se é true saimos do bucle e acabamos o xogo. 
         if (palabraIncognita.equals(palabraAcertada)){
             adivinado = true;
            }
         
         } while (erros < errosTope && adivinado == false); // o xogo executase mentres non adiviñemos a palabra nen
                                                            // os nosos erros superen o tope de erros.
       
         // se o xogo acabou porque nos pasamos do tope de erros
         if (adivinado == false){
            System.out.println("\nPLOFF!! \nO xogo rematou porque te pasaches de erros.\nA palabra era: " + palabraIncognita.toUpperCase() );
         }else {
            System.out.println("\nNORABOA!!. Acertaches todas as letras!!!!");
         }
         
    }
    
          
}
