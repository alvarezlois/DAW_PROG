/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ahorcado;
import javax.swing.JOptionPane;
/**
 *
 * @author adrian
 */
public class Palabra {
    
    public String palabraIncognita ;
    
    
    // Método que pida a palabra a buscar (palabraIncognita)
    public String pedirIncognita (){
        palabraIncognita = JOptionPane.showInputDialog("Introduce la palabra a buscar");
        palabraIncognita = palabraIncognita.toLowerCase();
        return palabraIncognita;
    }
    
    // Método que crea a palabra acertada.
    // Esa palabra terá unha lonxitude igual á lonxitude da palabra incógnita.
    // Ao principio só estará formada por caracteres ????
    public String iniciarPalabra (int longitud){
        String caracteres = "";
        int i;
        for(i=0; i<longitud;i++){
        caracteres = caracteres + "?";
        }
        return caracteres;
    }
    // Método que comproba se acertamos a letra introducida e se é así
    // introduce esa letra no string palabraAcertada no lugar do ????
     public String comprobarLetra (String palabraIncognita, String letra, String palabraAcertada){
     int i;
     String palabraComprobada = "";
         // recorremos a incógnita e cando a letra nosa coincida cunha letra na posición i da icognita...
        for (i = 0; i < palabraIncognita.length(); i++){
            if (letra.charAt(0) == palabraIncognita.charAt(i)){ // se acertamos unha letra...
                // cambiamos o caracter da palabraAcertada pola letra que acabamos de adiviñar
                /*
                char oldChar = palabraIncognita.charAt(i);
                char newChar = letra.charAt(0);
                palabraResolta = palabraAcertada.replace(oldChar, newChar);
                System.out.println("A letra " + letra + "  está na palabra.");                
                */
                palabraComprobada += letra.charAt(0);
             } else {
                palabraComprobada += palabraAcertada.charAt(i);
                //System.out.println("A letra " + letra + " non está na palabra.");
            
            }            
         }
     return palabraComprobada;
     } 
         
}
    

     
    
