/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ahorcado;
import javax.swing.JOptionPane;

/**
 *
 * @author adrian
 */
public class Jugador {
    String nomeXogador = "";
    
    // método que nos pida o nome do xogador
    public String pedirNomeXogador (){
        nomeXogador = JOptionPane.showInputDialog("Introduce el nombre del jugador");
        return nomeXogador;
    }
    
      // Método que comproba se a letra está na palabra incógnita e
      // contabiliza o número de acertos.
    public int contarAcertos (String palabraIncognita, String letra){
    int i;
    int acerto = 0;
   /*
    Recorremos o string palabraIncognita e cando un caracter i coincida coa nosa letra
    o que facemos é sumar 1 ao acerto.
    */
    for (i = 0; i < palabraIncognita.length(); i++){
        if (palabraIncognita.charAt(i) != letra.charAt(0)){
        } else {
            acerto++;
        }
      }
    return acerto;
    }  
    
}
