package Ejercicio01;
import java.util.Scanner;

public class Persona {
    String nombre;
    int edad;
    float altura;

    public String consulta_Nombre(){
        return nombre;
    }

    public void cambia_Nombre(String nom){
        nombre=nom;
    }
    
    // métodos de consulta e modificación do resto de atributos
    // apartado 2 da tarefa
    public int consulta_Edad(){
        return edad;
    }

    public void cambia_Edad(int ed){
        edad=ed;
    }
    
    public float consulta_Altura(){
        return altura;
    }

    public void cambia_Altura(float alt){
        altura=alt;
    }
    
    
    // Metodo constructor da clase Persona
    // Implementado como requisito do apartado 3 da tarefa
    public Persona() {
        nombre="Sara López Fuentes";
        edad=32;
        altura=1.70f ;
    }

    
    /**
     * 
     * Metodo constructor con parámetros da clase Persona
     * Implementado como requisito do apartado 4 da tarefa
     * 
     * @param nombre String que contiene el nombre para la persona
     * @param edad int con la edad de la persona
     * @param altura float con la altura de la persona
     * 
     */
    public Persona(String nombre, int edad, float altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
    }
    
}
