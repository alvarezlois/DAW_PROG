package Ejercicio01;

import java.util.Scanner;

public class Ejercicio01 {

    public static void main(String[] args) {
        // leremos o nome por teclado
        Scanner teclado = new Scanner( System.in );
        String nombre;
        // creamos unha nova instancia de persoa
        Persona persona = new Persona();
        
        // lemos o nome para a persoa     
        System.out.println( "Introducir nome para a persona: " ); 
        nombre = teclado.nextLine();
        // Asignamos o nome da persona
        persona.cambia_Nombre(nombre);
        // Amosamos o nombre da persoa
        System.out.println( "O nome da persona é: " + persona.consulta_Nombre() ); 
    }
}

