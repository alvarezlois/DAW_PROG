package numeros;


public class Complejo {
    double real;
    double imag;
    
    /**
     * Constructor que inicializa os atributos a cero.
     */
    public Complejo() {
      real = 0;
      imag = 0;
    }
    
    /**
     * 
     * Constructor que inicializa os atributos aos valores indicados 
     * polos parámetros.
     * 
     * @param real parte real do número complexo
     * @param imag parte imaxinaria do número complexo
     * 
     */
    public Complejo(double real, double imag) {
        this.real = real;
        this.imag = imag;
    }
    
    /**
     * 
     * @return Devolve a parte real do obxecto.
     */
    public double consulta_Real() {
        return real;
    }
    
    /**
     * 
     * @return Devolve a parte imaxinaria do obxecto.
     */
    public double consulta_Imag() {
        return imag;
    }
    
    /**
     * Asigna á parte real do obxecto o valor indicado no parámetro real.
     * 
     * @param real valor co que modificar a parte real do número complexo
     */
    public void cambia_Real(double real) {
        this.real = real;
    }
    
    /**
     * Asigna á parte imaxinaria do obxecto o valor indicado no 
     * parámetro imag.
     * 
     * @param imag valor co que modificar a parte imaxinaria do número complexo
     */
    public void cambia_Imag(double imag) {
        this.imag = imag;
    }
    
    /**
     * Convirte a String o número complexo, mediante a concatenación dos seus
     * atributos e devolve como resultado a cadea de texto que representa ao
     * número complexo en forma binomial.
     * 
     * @return Cadea de texto que representa ao número complexo en forma binomial 
     */
    @Override
    public String toString() {
        String signo;
        // Seleccionamos o caracter correspondente a amosar en función de se
        // a parte real é positiva ou negativa
        signo = Math.abs(imag)==imag ? "+" : "-";
        // compoñemos e retornamos o string
        return real + " " + signo + " " + Math.abs(imag) + "*i";
    }
    
    
    /**
     * Suma a parte real coa parte real do número complexo b e a parte 
     * imaxinaria coa parte imaxinaria do número complexo b.
     * 
     * @param b : número complexo a sumar
     */
    public void sumar(Complejo b) {
        this.real += b.real;
        this.imag += b.imag;
    }
}
