package Ejercicio03;
import Ejercicio01.Persona; 

public class Ejercicio03 {

    /**
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        // creamos unha Persoa
        Persona persona = new Persona();
        // e monstramos os seus atributos
        System.out.printf("\nNombre: %s" , persona.consulta_Nombre());
        System.out.printf("\nEdad: %d" , persona.consulta_Edad());
        System.out.printf("\nAltura: %.2f\n" , persona.consulta_Altura());
        
    }
}
