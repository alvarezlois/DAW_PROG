package Ejercicio04;

import Ejercicio01.Persona;

public class Ejercicio04 {

    public static void main(String[] args) {
        // creamos unha Persoa
        Persona persona = new Persona("Fernando Arnedo", 48, 1.69f);
        // e monstramos os seus atributos
        System.out.printf("\nNombre: %s" , persona.consulta_Nombre());
        System.out.printf("\nEdad: %d" , persona.consulta_Edad());
        System.out.printf("\nAltura: %.2f\n" , persona.consulta_Altura());
    }
}
