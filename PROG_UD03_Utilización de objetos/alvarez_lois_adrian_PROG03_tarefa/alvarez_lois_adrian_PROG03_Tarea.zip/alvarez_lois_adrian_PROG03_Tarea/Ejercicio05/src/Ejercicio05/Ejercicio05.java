
package Ejercicio05;

import java.util.Scanner;

// A clase Complejo atopase no paquete numeros do proxecto 
import numeros.Complejo;

public class Ejercicio05 {

    public static void main(String[] args) {
        
        // leremos datos por teclado
        Scanner teclado = new Scanner( System.in );
        Complejo c1, c2;
        double r, i;
        
        // creamos un obxecto da clase Complejo co constructor sen
        // parámetros.
        c1 = new Complejo();
        System.out.print("\nCreado complejo c1 con construtor sin parámetros");
        // y monstramos sus atributos
        System.out.print("\nMostrando complejo creado con construtor sin parámetros");
        System.out.print("\n\tParte real: " + c1.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c1.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c1.toString());
        
        // lemos os valores da parte real e a parte imaxinaria para asignar a c1
        System.out.print("\nIntroduzca el valor de la parte real para c1: ");
        r = teclado.nextDouble();
        
        System.out.print("Introduzca el valor de la parte imaginaria para c1: ");
        i = teclado.nextDouble();
             
        // modificamos c1 cos valores introducidos
        c1.cambia_Real(r);
        c1.cambia_Imag(i);
        // y mostramos los nuevos valores
        System.out.print("Mostrando los nuevos valores de c1");
        System.out.print("\n\tParte real: " + c1.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c1.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c1.toString());
        
        // lemos os valores da parte real e parte imaxinaria para asignar a c2
        System.out.print("\nIntroduzca el valor de la parte real para c2: ");
        r = teclado.nextDouble();
        
        System.out.print("Introduzca el valor de la parte imaginaria para c2: ");
        i = teclado.nextDouble();
        
        // creamos c2 coos valores introducidos
        c2 = new Complejo(r, i);
        System.out.print("Creado complejo c2 con construtor con los valores "
                           + "introducidos como parámetros");
        // e monstramos oos seus atributos
        System.out.print("\nMostrando complejo creado con construtor sin parámetros");
        System.out.print("\n\tParte real: %f" + c2.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c2.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c2.toString());
        
        // sumamos a c2 o complexo c1
        System.out.print("\nSumamos a c2 el complejo c1");
        c2.sumar(c1);
        // e monstramos os seus atributos
        System.out.print("\nMostrando complejo c2 tras la suma");
        System.out.print("\n\tParte real: " + c2.consulta_Real());
        System.out.print("\n\tParte imaginaria: " + c2.consulta_Imag());
        System.out.print("\n\tForma binomial: " + c2.toString());
        
    }
}
