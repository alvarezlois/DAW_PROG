/*
 * Clase que representa los numeros complejos
 * y define una serie de metodos para ellos
 */

package numeros;

/**
 *
 * @author profesor
 */
public class Complejo {
    double real, imag;

    public Complejo() {
        real=0.0;
        imag=0.0;
    }

    public Complejo(double real, double imag) {
        this.real=real;
        this.imag=imag;
    }

    public double consulta_Real(){
        return real;
    }

    public double consulta_Imag(){
        return imag;
    }

    public void cambia_Real(double real){
        this.real=real;
    }

    public void cambia_Imag(double imag){
        this.imag=imag;
    }

    public String toString() {
        return " " + real + " + " +imag + "i";
    }

   
    public void sumar(Complejo b){
        this.real+=b.real;
        this.imag+=b.imag;
    }

     public static void main(String[] args) {

        Complejo a = new Complejo();
        Complejo b = new Complejo(2,3);

        a.cambia_Real(4);
        a.cambia_Imag(7);

        System.out.println("Numero complejo a: " + a.toString());
        System.out.println("Numero complejo b: " + b.toString());

        a.sumar(b);
        System.out.println("Suma a + b: " + a.toString());



    }

}
