package net.iessanclemente.naipes;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;


/**
 *
 * @author pepinho.com
 */
public abstract class Baralla implements Serializable {
    private final Naipe[] cartas;

    /*
    * Constantes
    */
    public static final Random ALEATORIO = new Random();
    public static int NUM_INTERCAMBIOS = 1500;
    public static final String ARCHIVO_DATOS = "baraja.dat";

    public Baralla(int numCartas){
        cartas = new Naipe[numCartas];
    }

    public Naipe[] getCartas() {
        return cartas;
    }
    
    public void setCarta(Naipe carta, int i){
        if(cartas!=null && i<cartas.length && i>=0)
            this.cartas[i] = carta;
    }
    

    public int getNumCartas(){
        int conta = 0;
        if(cartas!=null)
            for (Naipe carta : cartas) {
                if (carta != null) {
                    conta++;
                }
            }
        return conta;
    }

    public int getNumCartasBaralla(){
        return (cartas==null) ? 0 : cartas.length;
    }

    public Naipe retirarCarta(){
        for(int i=cartas.length-1; i>=0; i--)
            if(cartas[i]!=null){
                Naipe p = cartas[i];
                cartas[i]=null;
                return p;
            }
        return null;
    }


    /**
     * Intercambia dos cartas que están en las posiciones i y j.
     * Podría ser publico o privado... si no nos interesa que se puedan
     * intercambiar cartas desde "fuera".
     * @param i
     * @param j 
     */
    public void intercambiar(int i, int j){
        if(cartas==null || i<0 || i>=cartas.length || j<0 || j>=cartas.length)
            return;
        Naipe p = null;
        p = cartas[i];
        cartas[i] = cartas[j];
        cartas[j] = p;
    }

    /**
     * Baraja las cartas.
     */
    public void barallar(){
        int j, k; // se intercambiarán dos índices aleatorios.
        int tam = cartas.length; // los índices deben ser menores que el tamaño de la Baraja.
        for(int i=0; i<NUM_INTERCAMBIOS; i++){
            j = ALEATORIO.nextInt(tam); // obtenemos un indice aleatorio j
            k = ALEATORIO.nextInt(tam); // obtenemos un indice aleatorio k
            if(j!=k) intercambiar(j,k); // si no son el mismo índice se intercambian.
        }
    }

   /* public void setCartas(Naipe[] cartas) {
        this.cartas = cartas;
    }*/
    
    public boolean saveBaralla() {
        return saveBaralla(ARCHIVO_DATOS);
    }
    /**
     * 
     * @param archivo nombre del archivo, sin ruta.
     * @return 
     */
    public boolean saveBaralla(String archivo) {
        boolean resultado = true;
        ObjectOutputStream oos = null;
        try {
            Path p = Paths.get(System.getProperty("user.dir"), archivo);
            if(Files.notExists(p)){
                Files.createFile(p);
            }
            oos = new ObjectOutputStream(new BufferedOutputStream(
                    new FileOutputStream(p.toFile())));
            oos.writeObject(this);
            oos.close();
        } catch (FileNotFoundException ex) {
            resultado = false;
            System.out.println("Aruivo non atopado: " + ex.getMessage()); 
        } catch (IOException ex) {
            resultado = false;
            System.out.println("Erro de E/S: " + ex.getMessage()); 
        } finally {
            try {
                if(oos!= null)
                    oos.close();
            } catch (IOException ex) {
                System.out.println("Erro ó pechar o arquivo: " + 
                        ex.getMessage()); 
            }
        }
        return resultado;
    }
    
    public static Baralla loadBaralla() {
        return loadBaralla(ARCHIVO_DATOS);
    }
    
    public static Baralla loadBaralla(String archivo) {
        Baralla resultado = null;
        ObjectInputStream oos = null;
        try {
            Path p = Paths.get(System.getProperty("user.dir"), archivo);
            if(Files.notExists(p)){
                Files.createFile(p);
            }
            oos = new ObjectInputStream(new BufferedInputStream(
                    new FileInputStream(p.toFile())));
            resultado = (Baralla) oos.readObject();
            oos.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Arquivo non atopado: " + ex.getMessage()); 
        } catch (IOException ex) {
            System.out.println("Erro de E/S: " + ex.getMessage()); 
        } catch (ClassNotFoundException ex) {
            System.out.println("Clase non atopada " + ex.getMessage()); 
        } finally {
            try {
                if(oos!= null)
                    oos.close();
            } catch (IOException ex) {
                System.out.println("Erro ó pechar o arquivo: " + 
                        ex.getMessage()); 
            }
        }
        return resultado;
    }
    

    @Override
    public abstract String toString();

}
