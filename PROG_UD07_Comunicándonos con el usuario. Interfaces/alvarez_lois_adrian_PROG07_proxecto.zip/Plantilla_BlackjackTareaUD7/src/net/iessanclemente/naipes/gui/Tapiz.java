/*
 * Este programa puede utilizarse con absoluta libertad.
 *  No está sujeto a licencia.
 */
package net.iessanclemente.naipes.gui;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import net.iessanclemente.naipes.BarallaInglesa;
import net.iessanclemente.naipes.Naipe;


import java.util.ArrayList;
import net.iessanclemente.naipes.IsNotANaipeNumberException;
/**
 *
 * @author pepecalo
 */

public final class Tapiz extends JPanel implements MouseListener {

 

    /*
    * ancho y alto del tapiz por defecto.
    * color de fondo por defecto.
    */
       
    // Ancho y alto del panel por defecto:
    static int ANCHO = 675;
    static int ALTO = 400;

    // Color de fondo del panel, de tipo java.awt.Color
    Color COR_FONDO = new Color (64, 132, 71);
        
    // Imágenes
    public static final Image IMG_JOKER_B
            = new ImageIcon(Naipe.class.getResource(
                    "/net/iessanclemente/naipes/imaxes/jokerb.png")).getImage();

    public static final Image IMG_JOKER_R
            = new ImageIcon(Naipe.class.getResource(
                    "/net/iessanclemente/naipes/imaxes/jokerr.png")).getImage();

    public static final Image IMG_TAPADA
            = new ImageIcon(Naipe.class.getResource(
                    "/net/iessanclemente/naipes/imaxes/backr.png")).getImage();

    /*
     * Propiedades
     */
    
    // baraja del blackjack que hay en el tapiz
    private BarallaInglesa baralla;
    
    // cartas que le salen la banca
    private ArrayList<Naipe> banca = new ArrayList<Naipe>();
            
    // cartas que le salen al jugador 1
    private ArrayList<Naipe> xogador1 = new ArrayList<Naipe>();
    
    // cartas que le salen al jugador 2
    private ArrayList<Naipe> xogador2 = new ArrayList<Naipe>();
    
    // entero que indica a quién le corresponde el turno (0=banca, 1=xogador1, 2=xogador2)
    private int turno;
    
    // array de 3 booleanos con valores que indican si algún o varios jugadores pasan
    private boolean[] pasa = new boolean[3];
  
      
    // constructor que recoge un booleano, indicando si la baraja tendrá o no comodín
    public Tapiz(boolean comodin) {
        baralla = new BarallaInglesa(comodin);
        baralla.barallar();
        setBackground(COR_FONDO);
        setPreferredSize(new Dimension (ALTO , ANCHO));
        addMouseListener(this);
    }
    
    // constructor por defecto. Le pasamos un false al anterior
    public Tapiz() {
        this(false);
    }
    
    
// Método de instancia getImageBaralla que devuelve la imagen asociada a la última carta de la baraja
    public Image getImageBaralla() {
        Naipe[] cartas = baralla.getCartas(); // dará error si baralla es nulo
        for (int i = cartas.length - 1; i >= 0; i--) {
            if (cartas[i] != null) {
                return getImage(cartas[i]);
            }
        }
        return null;
    }

// Método estático (public static) getImage que recoge un Naipe y devuelve un objeto de tipo Image con la representación del Naipe
    public static Image getImage(Naipe n) {
        if(n==null || n.isTapada())
            return IMG_TAPADA;
        Image img;
        try {
            img = new ImageIcon(Naipe.class.getResource(
                    "/net/iessanclemente/naipes/imaxes/"
                    + n.getNumero() + "-" + n.getPau().getValor() + ".png")).getImage();
        } catch (Exception e) {
            img = null;
        }
        return img;
    }

// método de swing para personalizar como se pinta un componente
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Image img = getImageBaralla();
        g.drawImage(img, 15, 30, this);
        // Pintar las cartas da banca, desde la posición 180, 30 con intervalos de 35 píxel en vertical entre cada naipe
        for (int i=0; i < banca.size(); i++){
            g.drawImage(getImage(banca.get(i)), 180, 30+35*i, this);
        }
        // Pintar las cartas del jugador 1, desde la posición 345, 30 con intervalos de 35 píxel en vertical entre cada naipe
        for (int i=0; i < xogador1.size(); i++){
            g.drawImage(getImage(xogador1.get(i)), 345, 30+35*i, this);
        }
        // Pintar las cartas del jugador 2, desde la posición 510, 30 con intervalos de 35 píxel en vertical entre cada naipe
        for (int i=0; i < xogador2.size(); i++){
            g.drawImage(getImage(xogador2.get(i)), 510, 30+35*i, this);
        }
        
    }
    
// Método reiniciar(), que reinicia el juego
    public void reiniciar(){
        // Borra/limpia los naipes da banca, del jugador 1 e 2
            banca.clear();
            xogador1.clear();
            xogador2.clear();
        // Inicia la baraja, llamando al método iniciar() de BarallaInglesa
            try {
                baralla.iniciar();
            } catch (IsNotANaipeNumberException ex) {
                System.out.println("Erro ó iniciar a baralla: " + ex.getMessage()); 
            }
        // Baraja las cartas da baraja, llamando al método barallar() de Baralla
            baralla.barallar();
        // Pone el turno a 0 y cada un dos elementos del array “pasa” a false
            turno = 0;
            for (int i = 0; i < pasa.length; i++){
                pasa[i] = false;
            }
        // Repinta el panel/tapiz (método repaint()).
            this.repaint();
    }
    
// seguinteTurno()
    public void seguinteTurno(){
        int i = 0;
        do {
            if (turno < 2) {
                turno = turno+1;
            } else {
                turno = 0;
            }
            i++;
        }
        while (pasa[turno] == true && i < 3);
    }
    
// implementar: mouseClicked(MouseEvent e)
// Para implementar la interface de los oyentes de ratón, MouseListener
    @Override
    public void mouseClicked(MouseEvent e) {
        // Si ha hecho doble clic (método getClickCount() del evento MouseEvent) y el jugador no pasa (!pasa[turno]) entonces:
        if (e.getClickCount() == 2 && pasa[turno]){
           // Retira una carta de la baraja (método retirarCarta()) y guardala
            Naipe retirada = baralla.retirarCarta();
            // Dependiendo de quién tenga el turno (turno), la añade a la colección correspondiente a ese jugador
            if (turno == 0){
                banca.add(retirada);
            }
            if (turno == 1){
                xogador1.add(retirada);
            }
            if (turno == 2){
                xogador2.add(retirada);
            }
            // Repinta el panel
            repaint();
            // Coge el siguiente turno (método seguinteTurno()).
            seguinteTurno();
        } else {
            // Si está pulsado la tecla de shift (método isShiftDown() del evento MouseEvent)
            if (e.isShiftDown()){
                // marca pasa[turno] = true y coge el siguiente turno
                pasa[turno] = true;
                seguinteTurno();
            }
        }
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    

} // Fin de la clase Tapiz
