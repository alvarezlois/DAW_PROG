
package net.iessanclemente.naipes.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;

/**
 *
 * @author adrian
 */
public class VentanaBlackjack extends JFrame{
    
// Constantes
    
    static final ImageIcon ICO = new ImageIcon(VentanaBlackjack.class.getResource("/net/iessanclemente/naipes/imaxes/ico16.png"));
    static final ImageIcon ICO_REINICIAR = new ImageIcon(VentanaBlackjack.class.getResource("/net/iessanclemente/naipes/imaxes/reiniciar.png"));
    static final ImageIcon ICO_SAIR = new ImageIcon(VentanaBlackjack.class.getResource("/net/iessanclemente/naipes/imaxes/sair.png"));
    
//Atributos 

    // tapiz: objeto de tipo Tapiz con el tapiz del juego.
    private Tapiz tapiz;
    // btSair: botón para salir del programa. Con la leyenda “Salir” y el icono ICO_SAIR.
    private final JButton btSair = new JButton("Saír", ICO_SAIR);
    // btReiniciar: botón para reiniciar el programa. Con la leyenda “Reiniciar” y el icono ICO_REINICIAR.
    private final JButton btReiniciar = new JButton("Reiniciar", ICO_REINICIAR);
    // Barra de Botones
    private JToolBar barraBotones;
    
// Un constructor que recoge el título da ventana. Este constructor debe tener las siguientes sentencias:    
    public VentanaBlackjack(String tit){
        // Llamar al constructor de la clase padre con el título.
        setTitle(tit);
        // Poner ICO como icono de la ventana.
        
        // Establecemos tamaño de la ventana
        setSize(500, 500);
        
        // Hacemos visible la ventana
        setVisible(true);
        
        // Ponemos la Barra de botones
        //JToolBar toolBar = getToolBar();
        //toolBar.setBounds(10, 10, 80, 80);
                        
        //añadiendo el listener a los botones para manipular los eventos del click
        //btSair.addActionListener(oyenteDeAccionS);
        //btReiniciar.addActionListener(oyenteDeAccionR);
        
        /*
         * Al darle a la “X” de la ventana NON DEBE HACER NADA, pues el control de salida del programa
         * debe hacerse por medio de eventos. Al pulsar en la X de la ventana o darle al botón btSair debe
         * preguntar si queremos salir del programa
        */
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        
        // Eventos Oyente de Accion
        //eventosOyenteDeAccionR();
        //eventosOyenteDeAccionS();
        // Eventos Oyente de Raton
        //eventosOyenteDeRaton();
        // Eventos Oyente de Ventana
        //eventosWindowListener();
       
        
        //agregando los botones al tapiz (panel)
        //tapiz.add(btSair);
        //tapiz.add(btReiniciar);
        //tapiz.add(toolBar);
        
        // Metodo que inicia los componentes 
        iniciarComponente();
        
        // Agregamos el panel a la ventana
        //this.getContentPane().add(tapiz);
    }
    
// **** FIN CONSTRUCTOR *****
    
   
 // MÉTODO PARA INICIAR LOS COMPONENTES. Botones, Paneles...
        private void iniciarComponente(){
    
        colocarPaneles();
        colocarToolBar();
              
        eventosOyenteDeAccionR();
        eventosOyenteDeAccionS();
        
    }
 
// Método que crea los paneles en la ventana
        private void colocarPaneles(){
            // Creación de un panel
            tapiz = new Tapiz(true);
            // Establecemos un color de fondo para el panel
            //panel.setBackground(Color.GREEN); 

            // Establecemos layout null para poder emplazar los elementos donde queramos
            //tapiz.setLayout(null);
            

            this.getContentPane().add(tapiz); // Agregamos el panel a la ventana
        }

        
// Método para crear un JToolBar con los dos botones y añadirlos a la parte superior da ventana.
        private void colocarToolBar() {
    barraBotones = new JToolBar();
    barraBotones.add(btSair);
    barraBotones.add(btReiniciar);
    //barraBotones.setBounds(10, 10, 80, 80);
    tapiz.add(barraBotones);
    
    }

       
// Agregando oyente de accion Reiniciar
private void eventosOyenteDeAccionR(){
        // Agregando un evento de accion para reiniciar
        ActionListener oyenteDeAccionR = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tapiz.reiniciar();
                
            }
        };
        // Agregamos el evento al botón
        btReiniciar.addActionListener(oyenteDeAccionR);
        
}
// Agregando oyente de accion Sair
private void eventosOyenteDeAccionS(){
        // Agregando un evento de accion para sair
        ActionListener oyenteDeAccionS = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                int confi = JOptionPane.showConfirmDialog(null, "Realmente desea salir del Black Jack?", "Confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE); 
                if(confi == JOptionPane.YES_OPTION)
                    JOptionPane.showMessageDialog(null, "Has seleccionado SI.");
                else if(confi == JOptionPane.NO_OPTION)
                    JOptionPane.showMessageDialog(null, "Has seleccionado NO.");
            }
        };
        // Agregamos el evento al botón
        btSair.addActionListener(oyenteDeAccionS);
        
}

// Agregando oyente del ratón
private void eventosOyenteDeRaton(){

    MouseListener oyenteDeRaton = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            tapiz.reiniciar();
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
        }

        @Override
        public void mouseExited(MouseEvent e) {
        }
    };
    
    
    btReiniciar.addMouseListener(oyenteDeRaton);
}
        
// Agregando oyente WindowListener
private void eventosWindowListener(){
    WindowListener oyenteDeVentana = new WindowListener() {
        @Override
        public void windowOpened(WindowEvent e) {
        }
        @Override
        public void windowClosing(WindowEvent e) {
            JOptionPane.showConfirmDialog(null, "Realmente desea salir del Black Jack?", "Confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE); 

        }
        @Override
        public void windowClosed(WindowEvent e) {
        }
        @Override
        public void windowIconified(WindowEvent e) {
        }
        @Override
        public void windowDeiconified(WindowEvent e) {
        }
        @Override
        public void windowActivated(WindowEvent e) {
        }
        @Override
        public void windowDeactivated(WindowEvent e) {
        }
    };
    
    //barraBotones.add(oyenteDeVentana);

}



}
