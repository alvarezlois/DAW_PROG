package net.iessanclemente.naipes;

import javax.swing.JDialog;
import javax.swing.JFrame;
import net.iessanclemente.naipes.gui.VentanaBlackjack;

/**
 *
 * @author pepinho.com
 */
public class AppJBlackjack {
    


    public static void main(String[] args) {
        VentanaBlackjack v1 = new VentanaBlackjack("Juego del Black Jack");
        
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
    }


}
