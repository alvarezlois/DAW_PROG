package net.iessanclemente.naipes;

import static net.iessanclemente.naipes.Naipe.*;
/**
 *
 * @author pepe
 */
public final class BarallaInglesa extends Baralla {
    public static final int NUM_CARTAS = 52;
    
    private boolean comodins = false; // no necesario, pues se inicializa al valor por defecto.

    public BarallaInglesa(){
        super(NUM_CARTAS);
        try {
            iniciar();
        } catch (IsNotANaipeNumberException ex) {
            System.out.println("Erro ó iniciar a baralla: " + ex.getMessage()); 
        }
    }

    public BarallaInglesa(boolean conComodines){
        super((conComodines) ? NUM_CARTAS+2 : NUM_CARTAS);
        comodins = conComodines;
        try {
            iniciar();
        } catch (IsNotANaipeNumberException ex) {
            System.out.println("Erro ó iniciar a baralla: " + ex.getMessage()); 
        }
    }

    public boolean hasComodines() {
        return comodins;
    }

    public void setComodines(boolean conComodines) {
        this.comodins = conComodines;
    }

    public void iniciar() throws IsNotANaipeNumberException{
        
        int t = 0;
        for (int i = 1; i <= NUM_CARTAS/NUM_PALOS; i++) {
            setCarta(new Naipe(i, Palo.DIAMANTES), t++);
            setCarta(new Naipe(i, Palo.PICAS), t++);
            setCarta(new Naipe(i, Palo.TREBOLES), t++);
            setCarta(new Naipe(i, Palo.CORAZONS), t++);
        }

        if(comodins){
            setCarta(new Naipe(Palo.JOKER_B), t++);
            setCarta(new Naipe(Palo.JOKER_R), t++);
        }
    }
        
    /*
    * Otra versión posible.
    */
    public void iniciar2() throws IsNotANaipeNumberException{
        // obtenemos las cartas a través del método público, pues las cartas son privadas en la clase Baraja.
        Naipe[] cartas = getCartas(); 
        int t = 0;
        for (int i = 1; i <= NUM_CARTAS/NUM_PALOS; i++) {
            cartas[t++] = new Naipe(i, Palo.DIAMANTES);
            cartas[t++] = new Naipe(i, Palo.PICAS);
            cartas[t++] = new Naipe(i, Palo.CORAZONS);
            cartas[t++] = new Naipe(i, Palo.TREBOLES);
        }
        if(comodins){
            cartas[t++] = new Naipe(Palo.JOKER_B);
            cartas[t++] = new Naipe(Palo.JOKER_R);
        }
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        Naipe[] cartas = getCartas();
        for (Naipe carta : cartas) {
            sb.append(carta).append("\n");
        }
        return sb.toString();
    }

}
