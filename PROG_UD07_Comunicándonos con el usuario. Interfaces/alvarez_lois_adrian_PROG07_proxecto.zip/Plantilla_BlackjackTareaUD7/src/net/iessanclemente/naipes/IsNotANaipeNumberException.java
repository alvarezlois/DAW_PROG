/*
 * Este programa puede utilizarse con absoluta libertad.
 *  No está sujeto a licencia.
 */
package net.iessanclemente.naipes;

/**
 *
 * @author pepecalo
 */
public class IsNotANaipeNumberException extends Exception {
    
    private int numero;
    
    public IsNotANaipeNumberException(String mensaxe, int numero){
        super(mensaxe);
        this.numero = numero;
    }

    @Override
    public String getMessage() {
        return "O numero " + numero + " non é válido. " + super.getMessage(); 
    }

    @Override
    public String toString() {
        return "O valor do número non é válido, debe ser una constante numérica"
                + "dentro del rango de valores posibles." + super.toString(); 
    }
    
    

}
