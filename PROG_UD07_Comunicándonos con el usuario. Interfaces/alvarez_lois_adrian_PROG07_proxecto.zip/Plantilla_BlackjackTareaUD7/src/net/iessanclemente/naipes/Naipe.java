package net.iessanclemente.naipes;

import java.io.Serializable;

/**
 *
 * @author pepinho.com
 */
public final class Naipe implements Comparable<Naipe>, Serializable {
    /*
     * TAREA: enumeraciones
     */
    public enum Palo {
        OROS(1), COPAS (2), BASTOS(3), ESPADAS(4),
        DIAMANTES(-1), PICAS(-2), TREBOLES(-3), CORAZONS(-4),
        JOKER_R(0), JOKER_B(-5);
        
        // Atributo
        private final int valor;
        
        // Constructor
        private Palo(int valor){
            this.valor = valor;
        }

        public int getValor() {
            return valor;
        }
        
        public static boolean isValidPalo(int i){
            for (Palo palo : Palo.values()) {
                if(palo.getValor()==i)
                    return true;
            }
            return false;
        }
    }
    
    /*
    * Atributos estáticos = constantes de todos los Naipes.
    */
    public static final int NUM_PALOS = 4;

    // Figura españolas
    public static final int SOTA = 10;
    public static final int CABALO = 11;
    public static final int REI = 12;

    // Figura inglesas
    public static final int JACK = 11;
    public static final int QUEEN = 12;
    public static final int KING = 13;
    public static final int JOKER = 0;

    /*
    * Atributos de Naipe
    */
    private int numero;
    private Palo pau;
    private boolean tapada = true;

    /*
    * Constructores
    */
    public Naipe(int numero, Palo pau) throws IsNotANaipeNumberException {
        // this.numero = numero;
        this.pau = pau;
        setNumero(numero);
    }

    public Naipe(Palo pau){
        this.pau = pau;
        this.numero = JOKER;
    }

    /*
    * Este constructor no se pide.
    */
    /*   
    public Naipe(boolean vermello){
        this(JOKER, (vermello) ? JOKER_R : JOKER_B);
    }*/

    /*
    * Métodos get/set para el número.
    */
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) throws IsNotANaipeNumberException{
        switch(numero){ // puede hacerse con un if, pero lo pongo para que veáis otros usos de switch.
            case JOKER: case 1:
            case 2:case 3: case 4: case 5: case 6:
            case 7: case 8: case 9: case 10: case JACK: 
            case QUEEN: case KING: break;
            default:
                throw new IsNotANaipeNumberException("Número non válido", numero);
        }
        this.numero = numero;
    }

    /*
    * Métodos get/set para el palo de l Naipe.
    */
    public Palo getPau() {
        return pau;
    }

    public void setPau(Palo palo) {
        this.pau = palo;
    }

    /*
    * Métodos get/set para el atributo "tapada".
    */
    public boolean isTapada() {
        return tapada;
    }

    public void setTapada(boolean tapada) {
        this.tapada = tapada;
    }
    
    /**
     * Devuelve el palo como cadena. Tanto para baraja española como inglesa o
     * francesa.
     * @return el palo como cadena
     */
    public String getPauAsString(){
        switch(pau){
            case OROS:
                 return "oros";
            case COPAS:
                 return "copas";
            case BASTOS:
                 return "bastos";
            case ESPADAS:
                 return "espadas";
            case DIAMANTES:
                 return "diamantes";
            case PICAS:
                 return "picas";
            case TREBOLES:
                 return "tréboles";
            case CORAZONS:
                 return "corazones";
            case JOKER_R:
                 return "joker vermello";
            case JOKER_B:
                 return "joker azul";
            default:
                return "";
        }
    }

    /*
    * No se pide
    */
    public String getNumeroEspAsString(){
        switch (numero) {
            case 1: return "as";
            case SOTA: return "sota";
            case CABALO: return "cabalo";
            case REI: return "rei";
        }
        return String.valueOf(numero);
    }

    public String getNumeroAsString(){
        /* Java 12 o sup. permite expresiones, que facilitarían la escritura, 
        pero probablemente no se entendería en este momento...*/
        switch(numero){
            case JOKER: return "comodin";
            case 1: return "as";
            case 2:case 3: case 4: case 5: case 6: 
            case 7: case 8: case 9: case 10:
                return String.valueOf(numero);
            case JACK: return "jack";
            case QUEEN: return "raíña";
            case KING: return "rei";
            default: return "";
        }
    }

    /*public String getStringEsp(){
        return getNumeroEspAsString() + " de " + getPauAsString();
    }*/

   /* public String getStringIng(){
        return getNumeroIng() + " de " + getPauAsString();
    }*/

/**
 * Devuelve el valor de la figura para el juego. No se pide.
 * @return valor de la figura.
 */
    public int getValor(){
        switch(numero){
            case 1: return 11;
            case QUEEN:
            case KING:
            case JACK: return 10;
            default:
                return numero;
        }
    }

    @Override
    public String toString(){
        return getNumeroAsString() + " de " + getPauAsString() + 
                ((!tapada) ? " [descuberta] " : "[*]");
    }

    /*
    * 
    */
    @Override
    public int compareTo(Naipe n) {
        return (pau!=n.getPau()) ? pau.getValor() : numero-n.getNumero();
    }
    

}
