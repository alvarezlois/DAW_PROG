/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo1;

import User.Diccionario;
import com.intersys.objects.CacheDatabase;
import com.intersys.objects.CacheException;
import com.intersys.objects.Id;
import java.sql.*;
import java.util.Iterator;
import java.util.Map;
import util.*;

/**
 *
 * @author Salvador Romero
 */
public class Ejemplo2 {

    public static void main(String[] args) throws SQLException, CacheException {
        ConexionACache cac = new ConexionACache();
        Connection conn = null;
            try {
                String Usuario = UtilConsola.leerCadena("Usuario : ", true);
                String Password = UtilConsola.leerCadena("Contraseña : ", true);
                String DB = UtilConsola.leerCadena("Namespace: ", true);
                conn = cac.construirConexion(DB, Usuario, Password);
                String opcion = "--";
                while (conn!=null && !opcion.equals("s")) {
                    opcion = PedidorDeDatos.PedirTareaARealizar();                    
                    switch (opcion.charAt(0)) {
                        case 'a': //Mostrar término y sus traduciones.
                        {   String termino = PedidorDeDatos.pedirTermino();
                            if (termino != null) {
                                PreparedStatement ps = conn.prepareStatement("SELECT %ID FROM Diccionario WHERE termino like ?");
                                ps.setString(1, "%" + termino + "%");
                                ResultSet rs = ps.executeQuery();
                                System.out.println("-------------------------------");
                                System.out.println("Mostrando términos encontrados:");
                                System.out.println("-------------------------------");
                                int i = 0;
                                while (rs.next()) {
                                    i++;
                                    String id = rs.getString(1);
                                    Diccionario d = (Diccionario) Diccionario.open(CacheDatabase.getDatabase(conn), new Id(id));
                                    System.out.println(d.gettermino());
                                    Iterator it = d.gettraducciones().keySet().iterator();
                                    while (it.hasNext()) {
                                        String language = (String) it.next();
                                        String translation = (String) d.gettraducciones().get(language);
                                        System.out.println("---> " + language + " = " + translation);
                                    }
                                    System.out.println("---# Termino consultado " + d.getconsultas() + " veces.");
                                    d.setconsultas(d.getconsultas() + 1);
                                    d._save();
                                }
                                System.out.println(i + " términos encontrados");
                            }
                        } break;
                        case 'b': 
                        {   //Introducir nuevo término.
                            Diccionario d = new Diccionario(CacheDatabase.getDatabase(conn));
                            d.settermino(PedidorDeDatos.pedirTermino());
                            Map m = PedidorDeDatos.pedirDatosTraducciones(d.gettermino());
                            d.gettraducciones().putAll(m);
                            d._save();
                        } break;
                        case 'c': //Borrar término.
                        {   String termino = PedidorDeDatos.pedirTermino();
                            if (termino != null) {
                                PreparedStatement ps = conn.prepareStatement("DELETE FROM Diccionario WHERE termino=?");
                                ps.setString(1,termino);
                                int del = ps.executeUpdate();
                                System.out.println("Eliminados "+del+" términos.");                                                                
                            }                          
                        } break;
                        case 's': //Salir
                                conn.close();
                            break;

                    }
                }
            } finally {
                if (conn != null && conn.isValid(5)) {
                    conn.close();
                }
            }      
    }
}
