/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo1;

import java.util.Map;
import java.util.HashMap;
import util.UtilConsola;

public class PedidorDeDatos {
   
   public static String PedirTareaARealizar()
   {
       System.out.println("Tareas disponibles:");
       System.out.println("-------------------------------------------");
       System.out.println(" a) Mostrar un término y sus traducciones. ");
       System.out.println(" b) Introduccir un nuevo término.");       
       System.out.println(" c) Elimina un nuevo término.");
       System.out.println(" s) Salir. ");
       System.out.println("-------------------------------------------");
       String t=UtilConsola.leerOpciones("Tarea a realizar:", "a=a,b=b,c=c,s=s", true ,true);       
       System.out.println();
       return t;
   }
    
    public static Map<String,String> pedirDatosTraducciones (String termino)
    {
        HashMap<String,String> traducciones=new HashMap<String,String>();
        int i=1;
        String q=UtilConsola.leerOpciones("¿Desea introducir la traducción "+i+" para el termino"+ termino +"? (si o no)", "s=s,si=s,no=n,n=n,y=s", true, true);
        while (q.equals("s")) {     
            String idioma=UtilConsola.leerCadena("Idioma: ", true);            
            String traduccion=UtilConsola.leerCadena("Traducción: ", true);
            traducciones.put(idioma, traduccion);
            q=UtilConsola.leerOpciones("¿Desea introducir la traducción "+i+" para el termino"+ termino +"? (si o no)", "s=s,si=s,no=n,n=n,y=s", true, true);
            i++;
        }
        return traducciones;
    }
    
    public static String pedirTermino()
    { 
        String r=UtilConsola.leerCadena("Introduzca el término:", true);
        System.out.println();
        return r;
    }
}
