/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package soluciontareaprog08;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

class ComparadorTelefonos implements Comparator<String>
{

    @Override
    public int compare(String o1, String o2) {
        if (o1.equals(o2)) return 0;
        if (o1.startsWith("+") && !o2.startsWith("+")) return 1;
        if (!o1.startsWith("+") && o2.startsWith("+")) return -1;
        long io1=Long.parseLong(o1.replaceAll("\\+", ""));
        long io2=Long.parseLong(o2.replaceAll("\\+", ""));
        if (io2<io1) return -1;
        else if (io2>io1) return 1;
        return 0;
    }
    
}

public class procesarClientes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Document d=DOMUtil.crearDOMVacio("datos_cliente");
        String datos=JOptionPane.showInputDialog("Introduce datos del cliente", "X12345678F,\"nombre\",\"apellidos\",+(82)12345678,612345678,test@TEST.com,(91)23456789,prueba@prueba.com,PRUEBA@prueba.com,+8212345678");
        if (datos==null && datos.length()==0)
        {
            d.appendChild(d.createComment("ERROR: No se ha introducido datos a procesar."));
        }
        else
        {
            String[] datosPartes=datos.split(",");
            if (datosPartes.length<=3)
            {
                d.appendChild(d.createComment("ERROR: Hay menos de 3 partes, separadas por comas, en la cadena introducida."));
            }
            else
            {
                //Creamos las expresiones regulares.
                Pattern DNI = Pattern.compile("[XYxy]?[0-9]{1,9}[A-Za-z]");
                Pattern NombreOApel = Pattern.compile("\"[\\w\\s]+\"");
                Pattern telefono=Pattern.compile("\\+*[0-9 \\(\\)]+");
                Pattern mail=Pattern.compile("[^@]+[@]{1}[^@]+");
                Element raiz=d.getDocumentElement();
                // Condición de salida, si se pone a true, es que hay un error y no se sigue procesando.
                boolean exit=false;
                
                // Eliminamos espacios sobrantes de cualquier parte.
                for (int i=0;i<datosPartes.length;i++) datosPartes[i]=datosPartes[i].trim();
                
                // Verificamos que el campo 0 sea el DNI.
                Matcher mDNI=DNI.matcher(datosPartes[0]);
                if (mDNI.matches()) 
                {
                    Element id=d.createElement("id");
                    id.setTextContent(datosPartes[0]);
                    raiz.appendChild(id);
                }
                else { exit=true; d.appendChild(d.createComment("ERROR: DNI o NIE no encontrado en posición 0.")); }
          
                // Verificamos que el campo 1 sea el Nombre.
                if (!exit) 
                {
                    Matcher mNombre=NombreOApel.matcher(datosPartes[1]);
                    if (mNombre.matches()) 
                    {
                        Element nombre=d.createElement("nombre");
                        nombre.setTextContent(datosPartes[1].replaceAll("\"", "").trim());
                        raiz.appendChild(nombre);
                    }
                    else { exit=true; d.appendChild(d.createComment("ERROR: Nombre no encontrado en posición 1.")); }
                }
                
                // Verificamos que el campo 2 sea los Apellidos
                if (!exit) 
                {
                    Matcher mApellidos=NombreOApel.matcher(datosPartes[2]);
                    if (mApellidos.matches()){
                        Element apellidos=d.createElement("apellidos");
                        apellidos.setTextContent(datosPartes[2].replaceAll("\"", "").trim());
                        raiz.appendChild(apellidos);
                    }
                    else { exit=true; d.appendChild(d.createComment("ERROR: Apellidos no encontrados en posición 2.")); }
                }
                
                // Analizamos el resto de campos, para determinar de que tipo es y los metemos en una lista.
                ArrayList<String> telefonos=new ArrayList<String>();
                ArrayList<String> mails=new ArrayList<String>();
                for (int i=3;i<datosPartes.length && !exit;i++)
                {
                    Matcher mTel=telefono.matcher(datosPartes[i]);
                    Matcher mMail=mail.matcher(datosPartes[i]);
                    if (mTel.matches())
                    {
                        String telpro=datosPartes[i].replaceAll("[\\(\\) ]", "").trim();
                        if (!telefonos.contains(telpro)) telefonos.add(telpro);
                        else d.appendChild(d.createComment("Advertencia: Telefono "+telpro+" duplicado")); 
                    }
                    else if (mMail.matches())
                    {
                        String mailpro=datosPartes[i].toLowerCase();
                        if (!mails.contains(mailpro)) mails.add(mailpro);
                        else d.appendChild(d.createComment("Advertencia: Mail "+mailpro+" duplicado"));
                    }
                    else 
                    {
                        exit=true; 
                        d.appendChild(d.createComment("ERROR: Campo "+i+" no esperado, se esperaba mail o telefono.")); 
                    }
                }
            
                // Ordenamos los telefonos.
                Collections.sort(telefonos,new ComparadorTelefonos());
                
                // Metemos los mails y los telefonos en el archivo XML
                Element telsNode=d.createElement("telefonos");
                telsNode.setAttribute("total",""+telefonos.size());
                for (String stelefono: telefonos)
                {
                    Element telNode=d.createElement("telefono");
                    telNode.setTextContent(stelefono);
                    telsNode.appendChild(telNode);
                }
                raiz.appendChild(telsNode);
                
                Element mailsNode=d.createElement("mails");
                mailsNode.setAttribute("total",""+mails.size());
                for (String smail: mails)
                {
                    Element mailNode=d.createElement("mail");
                    mailNode.setTextContent(smail);
                    mailsNode.appendChild(mailNode);
                }
                raiz.appendChild(mailsNode);
            }
        }
        JOptionPane.showMessageDialog(null, DOMUtil.DOM2XML(d), "Datos cliente en XML.", JOptionPane.INFORMATION_MESSAGE);
    }
}