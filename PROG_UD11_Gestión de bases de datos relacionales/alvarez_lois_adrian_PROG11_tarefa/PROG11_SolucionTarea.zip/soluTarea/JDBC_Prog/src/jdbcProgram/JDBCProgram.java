package jdbcProgram;

import javax.swing.JOptionPane;
import java.sql.*;

public class JDBCProgram{
	static Statement stmt;
	static PreparedStatement pstmt;
	static Connection con;

	public static void main(String args[]){

                int choice = -1;

		do{
                    try {
			choice = getChoice();
			if (choice != 0){
				getSelected(choice);
			}
                          } catch(NumberFormatException e) {
                  System.err.println("NO ES UN NÚMERO VÁLIDO: Vuelve a intentarlo.");}
		}
		while ( choice !=  0);
			System.exit(0);
           
           
	}

	public static int getChoice()
	{
            String choice;
            int ch;
            choice = JOptionPane.showInputDialog(null,
                "1. Crear tabla Clientes\n"+
                "2. Crear tabla Escrituras y EscCli\n"+
                "3. Insertar datos en la tabla Clientes\n"+
                "4. Insertar datos en la tabla Escrituras\n"+
                "5. Recuperar datos de la tabla Clientes\n"+
                "6. Recuperar datos de la tabla Escrituras\n"+
                "7. Actualizar en tabla Clientes\n"+
                "8. Listar el nombre de los Clientes que hicieron una escritura de compraventa\n"+
		"0. Salir \n"+
		"Escriba la opción.");
            ch = Integer.parseInt(choice);
            return ch;
	}

	public static void getSelected(int choice){
		if (choice==1)
                    crearClientes();
		if (choice==2)
                    createEscrituras();
		
		if(choice==3){
			insertarClientes();
		}
		if(choice==4){
			insertarEscrituras();
		}
		if(choice==5){
			obtenerClientes();
		}
		if(choice==6)
			obtenerEscrituras();
		
		if(choice==7)
			updateClientes();
		
		if(choice==8){
			consultaCompraventa();
		}
	}

	public static Connection getConnection()
	{

	    try {
              // Cargar el driver de mysql
              Class.forName("com.mysql.jdbc.Driver");

	     } catch(java.lang.ClassNotFoundException e) {
			System.err.print("ClassNotFoundException: ");
			System.err.println(e.getMessage());
	     }

	     try {
                     // Cadena de conexión para conectar con MySQL en localhost,
                     //seleccionar la base de datos llamada ‘test’
                     // con usuario y contraseña del servidor de MySQL: root y admin
                     String connectionUrl = "jdbc:mysql://localhost/test?" +
                                   "user=root&password=admin";
                     // Obtener la conexión
                     con = DriverManager.getConnection(connectionUrl);

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}

            return con;
	}

	public static void crearClientes()
	{
                con = getConnection();
		String createString;		
                createString = "CREATE TABLE Clientes (Cod_Cliente int(3), Nombre TEXT(25), Telefono TEXT(9), Constraint Cliente_PK Primary Key (Cod_Cliente))";

		try {
			stmt = con.createStatement();
	   		stmt.executeUpdate(createString);
			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
            JOptionPane.showMessageDialog(null,"Tabla de Clientes creada.");
	}

	public static void createEscrituras()
	{
                con = getConnection();

                String cS = "create table EscCli (" +
						"CodCli INT(3), " +
						"CodEsc INT(3))" ;    //, "+
                                                //", Constraint EsC_PK Primary Key (CodCli, CodEsc) )"  ;

                String cCla = "ALTER TABLE EscCli ADD CONSTRAINT PK_COD PRIMARY KEY(CodCli,CodEsc)" ;


		String createString;
		createString = "create table Escrituras (" +
						"Codigo INT(3), " +
						"tipo TEXT(4), "+
                                                "nom_fich TEXT(5), "+
						"num_interv  INT(2) , Constraint Esc_PK Primary Key (Codigo) )"  ;
                                                //+
                                                //", Constraint Empleado_FK FOREIGN KEY (Empleados) REFERENCES Empleados(Codigo_Empleado) )" ;
                String createString2 = "ALTER TABLE Escrituras ADD FOREIGN KEY (Id_Empleado) REFERENCES Empleados(Codigo_Empleado) " ;

		try {
			stmt = con.createStatement();
	   		stmt.executeUpdate(createString);
                        stmt.executeUpdate(createString2);
                        stmt.executeUpdate(cS);
                        stmt.executeUpdate(cCla);
			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	JOptionPane.showMessageDialog(null,"Tablas: Escrituras y EscCli creadas");
	}

	public static void insertarClientes()
	{
                con = getConnection();
                String insertString1, insertString2, insertString3, insertString4;
                insertString1 = "insert into Clientes values('211', 'José Javier', '666777888')";
                insertString2 = "insert into Clientes values('221', 'Narciso', '888777999')";
                insertString3 = "insert into Clientes values('231', 'José Ramón', '887778009')";
                insertString4 = "insert into Clientes values('241', 'Salvador', '777111000')";

		try {
			stmt = con.createStatement();
	   		stmt.executeUpdate(insertString1);
	   		stmt.executeUpdate(insertString2);
	   		stmt.executeUpdate(insertString3);
	   		stmt.executeUpdate(insertString4);

			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
            JOptionPane.showMessageDialog(null,"Datos insertados en la tabla Empleados");
	}

	
	public static void insertarEscrituras()
	{
            con = getConnection();

            String insertString1, insertString2, insertString3;
            insertString1 = "insert into Escrituras values(211, 'CPVE', 'Compraventa20112009.doc',2)";
            insertString2 = "insert into Escrituras values(011, 'TEST', 'Testamento12122010.doc', 1)";
            insertString3 = "insert into Escrituras values(211, 'CPVE', 'Compraventa10012010.doc',3)";
            String insertString4 = "insert into Escrituras values(345, 'SEGR', 'Segregación01012001',3)";

            String insertString5 = "insert into EscCli values(211,231)"  ;

	        try {
			stmt = con.createStatement();
	   		stmt.executeUpdate(insertString1);
	   		stmt.executeUpdate(insertString2);
	   		stmt.executeUpdate(insertString3);
                        stmt.executeUpdate(insertString4);
                        stmt.executeUpdate(insertString5);
			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	JOptionPane.showMessageDialog(null,"Datos insertados en la tabla Escrituras");
	}

	public static void obtenerClientes(){
	String result = null;
            try {
                con = getConnection();
		
		String selectString;
		selectString = "select * from Clientes";
	        result ="Cod\t \t Nombre\n";
		
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(selectString);
			while (rs.next()) {
			    int id = rs.getInt("Cod_Cliente");
			    String name = rs.getString("Nombre");
			    result += id + "\t \t" + name+"\n";
			}
			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
                JOptionPane.showMessageDialog(null, result);
	}

	public static void obtenerEscrituras(){
		 
                con = getConnection();
		String result = null;
		String selectString;
		selectString = "select * from Escrituras" ;
		result ="Código \t \t Tipo \t \t Num_intervinientes \t Nom_fichero \n";
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(selectString);
			while (rs.next()) {
				int pr_id = rs.getInt("Codigo");
				String prodName = rs.getString("tipo");
                                String nomf = rs.getString("nom_fich");
                                int id = rs.getInt("num_interv");
                                result += pr_id + "\t \t"+ prodName + "\t \t" + id + "\t \t" + nomf + "\n";
			}
			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	JOptionPane.showMessageDialog(null, result);
	}

	public static void updateClientes(){
		
                con = getConnection();

		String updateString1;
		updateString1 = "UPDATE Clientes SET Nombre = 'Diego' where Cod_Cliente = '211'";

		try {
			stmt = con.createStatement();
	   		stmt.executeUpdate(updateString1);

			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
        	JOptionPane.showMessageDialog(null,"Datos actualizados en la tabla Empleados");
	}

	

	public static void consultaCompraventa(){
		
                con = getConnection();
		String result = null;
		String selectString;
		selectString = "select Clientes.Nombre from Clientes, Escrituras, EscCli where tipo = 'CPVE' " +
			"and Clientes.Cod_Cliente = EscCli.CodCli and EscCli.CodEsc = Escrituras.Codigo ";
	        result ="Cliente \n";
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(selectString);
			while (rs.next()) {
			    String name = rs.getString("Nombre");
			    result += name+"\n";
			}
			stmt.close();
			con.close();

		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
                JOptionPane.showMessageDialog(null, result);
	}
}