
import java.util.Scanner;

/*
 * ejercicio8.java
 * Programa que realiza calculos con los operadores matematicos
 * y las funciones de la clase Math
 */
/**
 *
 * @author FMA
 */
public class ejercicio8 {

    //clase principal que inicia la aplicacion
    public static void main(String[] args) {
        // clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);
        double x , y;

        System.out.print( "Introducir primer numero: " );
        x = teclado.nextDouble(); // pedimos el primer numero al usuario
        System.out.print( "Introducir segundo numero: " );
        y = teclado.nextDouble(); // pedimos el segundo numero al usuario

        System.out.println("\tx = " + x + "\ty = " + y);

        // operaciones aritmeticas
        System.out.println("\tx + y = " + String.valueOf(x+y));
        System.out.println("\tx - y = " + String.valueOf(x-y));
        System.out.println("\tx * y = " + String.valueOf(x*y));
        System.out.println("\tx / y = " + String.valueOf(x/y));

        // operaciones algebraicas
        System.out.println("\tx ^ 2 = " + String.valueOf(Math.pow(x, 2)));
        System.out.println("\t\u221A x = " + String.valueOf(Math.sqrt(x)));

    } // fin main

} // fin ejercicio8
