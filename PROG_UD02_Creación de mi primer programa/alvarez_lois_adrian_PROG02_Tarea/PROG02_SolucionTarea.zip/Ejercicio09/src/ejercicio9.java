import java.util.Scanner;

/*
 * ejercicio9.java
 * Programa que solicita un numero de teclado
 * e imprime sus digitos separados
 */

/**
 *
 * @author FMA
 */
public class ejercicio9 {

    // clase principal que inicia la aplicacion
    public static void main(String[] args) {

        Scanner teclado = new Scanner (System.in);

        int num, d1, d2, d3, d4, d5;
        String cadena, resultado;

        System.out.print( "Introducir numero entero de 5 digitos: " );
        num = teclado.nextInt();


        d5 = num % 10;
        num = num /10;

        d4 = num % 10;
        num = num /10;

        d3 = num % 10;
        num = num /10;

        d2 = num % 10;
        num = num /10;

        d1 = num % 10;


        System.out.printf("\n\t%d\t%d\t%d\t%d\t%d\n", d1, d2, d3, d4, d5);



    } // fin main

} // fin ejercicio9
