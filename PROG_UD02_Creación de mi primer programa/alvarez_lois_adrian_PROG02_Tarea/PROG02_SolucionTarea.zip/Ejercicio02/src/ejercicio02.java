
public class ejercicio02 {

        public enum sexo {V,M};

    public static void main(String[] args) {
       	boolean casado;
	final int MAXIMO=999999;
	byte diasem ;
	short diaanual ;

        // segundos desde el 01/01/1970 hasta el 22/02/2001
        long miliseg ;
        float totalfactura;
        long poblacion6775235741L;
    }

}
