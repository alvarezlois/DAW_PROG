
import java.util.Scanner;

/*
 * ejercicio05.java
 * Determina si un numero es multiplo de otro
 */

/**
 *
 * @author FMA
 */
public class ejercicio05 {

    
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int x , y;
        String resultado;


        System.out.print( "Introducir primer numero: " );
        x = teclado.nextInt(); // pedimos el primer numero al usuario
        System.out.print( "Introducir segundo numero: " );
        y = teclado.nextInt(); // pedimos el segundo numero al usuario

        resultado = ((x%y)==0)?"es multiplo":"no es multiplo";
        System.out.println("\tx = " + x + " " + resultado + " de y = " + y);
    } // fin main

} // fin ejercicio05
