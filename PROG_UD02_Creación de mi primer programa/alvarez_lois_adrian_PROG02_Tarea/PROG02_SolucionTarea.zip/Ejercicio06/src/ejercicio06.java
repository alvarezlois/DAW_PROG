/*
 * ejercicio06.java
 * Tipos enumerados
 */

/**
 *
 * @author FMA
 */
public class ejercicio06 {

    // la lista
    public enum mes {
        ENERO, FEBRERO, MARZO,
        ABRIL, MAYO, JUNIO,
        JULIO, AGOSTO,SEPTIEMBRE,
        OCTUBRE,NOVIEMBRE,DICIEMBRE
    }
    public static void main(String[] args) {

        mes m = mes.MARZO;
        System.out.println("El valor de la variable de tipo enumerado m es: " + m);

        String mesactual="MARZO";
        m = mes.valueOf(mesactual);
        System.out.println("El valor de la variable de tipo enumerado m es: " + m);
    }

}
