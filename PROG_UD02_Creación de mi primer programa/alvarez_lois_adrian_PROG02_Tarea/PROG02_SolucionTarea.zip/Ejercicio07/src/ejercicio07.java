import java.util.Scanner;

/*
 * ejercicio07.java
 * Programa que resuelve una ecuación de 1er. grado
 */


/**
 *
 * @author FMA
 */
public class ejercicio07 {

   // clase principal que inicia la aplicacion
    public static void main(String[] args) {

        // clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);
        double c1, c2, x;
        String resultado;

        System.out.print( "Introducir primer numero C1: " );
        c1 = teclado.nextDouble(); // pedimos el primer numero al usuario
        System.out.print( "Introducir segundo numero C2: " );
        c2 = teclado.nextDouble(); // pedimos el segundo numero al usuario

        // si el coeficiente de x es cero la ecuacion no se puede calcular
        resultado = (c1==0)?"Error, la ecuacion no se puede calcular":String.valueOf(-c2/c1);

        System.out.println("El valor de x en la ecuacion C1x + C2 = 0 es " + resultado);


    } // fin main


} // fin ejercicio07
