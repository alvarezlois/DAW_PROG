/*
7. Gauss, gran matemático, ideó un método para calcular la fecha en la que celebrar la Pascua
de Resurrección (Semana Santa). El Algoritmo de Gauss para el cálculo de la  fecha de Pascua,
teniendo en cuenta que, si representamos como “x MOD y” el resto de la división entera “x/y”, es:
 
a = año mod 19
b = año mod 4
c = año mod 7
d = (19a + 24) mod 30
e = (2b + 4c + 6d + 5) mod 7
n = (22 + d + e)

Si el valor de n es menor o igual que 31, entonces el domingo de Pascua se corresponde con esa fecha de marzo.
En caso contrario, si es mayor, se corresponde con el mes de abril.
 
Haz un programa que pida el año e imprima la fecha que se corresponde con el domingo de Pascua.
Haz dos versiones del programa, una que use las mismas variables y otro que emplee sólo las variables año, d y n.
Importante: nombra las variables con el mismo nombre que las indicadas en el algoritmo.
 */
package PROG02_Ejer07a;
import java.util.Scanner;

/**
 *
 * @author adrian
 */

/**
Neste exercicio somentes uso as variables ano, d e n.

 SUPER IMPORTANTE A INFORMACIÓN QUE SAQUEI DESTA PÁXINA: 
 https://www.gaussianos.com/calcular-la-fecha-del-domingo-de-resurreccion/
*/
public class PROG02_Ejer07a {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           // Definimos as variables
        int ano, d, n;
        
        // pedimos o valor do ano
        Scanner sc = new Scanner(System.in);
        System.out.print("Ano do que se quere calcular a data do Domingo de Pascua: ");
        
        ano = sc.nextInt();
        
        // aplicamos o algoritmo
        d = (19*(ano%19) + 24) % 30;
        n = (22 + ((19*(ano%19) + 24) % 30) + ((2*(ano%4) + 4*(ano%7) + 6*d + 5) % 7));
        
        if (n<=31){
        System.out.println("O Domingo de Pascua corresponde ao " + (n) +  " de Marzo." );
        } else {
        System.out.println("O Domingo de Pascua corresponde ao " + (n-21-d) + " de Abril.");
        }
        
    }
    
}
