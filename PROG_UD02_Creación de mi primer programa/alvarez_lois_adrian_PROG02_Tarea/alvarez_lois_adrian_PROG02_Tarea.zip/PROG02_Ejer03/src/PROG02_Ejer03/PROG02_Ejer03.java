/*
Eu renomeei o proxecto como tarefa_02_ej03
 */
package PROG02_Ejer03; // Esta liña faltaba por incomporar

/**
 *
 * @author adrian
 */
public class PROG02_Ejer03 { 
     // int i = 1; // se invocamos a variable aquí o main non pode ter acceso a ela
    public static void main(String[] args) {  
        int i = 1; // ete é o lugar axeitado para colocar a variable. Dento do main
        while(i<10) {   
            if(i>3) {
                System.out.println("Ola");
            }  
        i++; // o único que se me ocorre é incrementar o valor de i dentro do bucle
            // e a partir de que toma o valor 4 comece a imprimir a mensaxe...
        
        }
        
  }
}