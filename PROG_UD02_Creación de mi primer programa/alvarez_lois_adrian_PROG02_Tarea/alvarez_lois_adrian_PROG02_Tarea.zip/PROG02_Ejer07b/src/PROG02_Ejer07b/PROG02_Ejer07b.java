/*
 Neste exercicio uso todas as variables.
 SUPER IMPORTANTE A INFORMACIÓN QUE SAQUEI DESTA PÁXINA: 
 https://www.gaussianos.com/calcular-la-fecha-del-domingo-de-resurreccion/
 */
package PROG02_Ejer07b;
import java.util.Scanner;

/**
 *
 * @author adrian
 */
public class PROG02_Ejer07b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Definimos as variables
        int ano, a, b, c, d, e, n;
        
        // pedimos o valor do ano
        Scanner sc = new Scanner(System.in);
        System.out.print("Ano do que se quere calcular a data do Domingo de Pascua: ");
        ano = sc.nextInt();
        
        // aplicamos o algoritmo
        a = ano % 19;
        b = ano % 4;
        c = ano % 7;
        d = (19*a + 24) % 30;
        e = (2*b + 4*c + 6*d + 5) % 7;
        n = (22 + d + e);
        
        if ((d + e) < 10){
        System.out.println("A data de Pascua de Resurrección será o día " + (n) + " de Marzo");
        }
        if ((d + e) > 9){
        System.out.println("A data de Pascua de Resurrección será o día " + (d + e - 9) + " de Abril");
        }
    }
    
}
