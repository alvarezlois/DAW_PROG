/*
* 5. Haz un programa en Java que determine si un año es bisiesto. Un año es bisiesto 
* si es múltiplo de 4 y no entre 100 (por ejemplo, 1984)
* o lo es entre 400 (1800 no fue bisiesto, 2000 sí ha sido).
 */
package PROG02_Ejer05;
import java.util.Scanner;
/**
 *
 * @author adrian
 */
public class PROG02_Ejer05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Creamos unha variable que almacene o ano que pediremos por teclado
        int ano;
        
        // solicitamos por teclado o valor do ano
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Escribe un ano para ver se é bisiesto: ");
        ano = sc.nextInt();
        
        // Introducimos os condicionais para ver se é ano bisiesto e imprimimos resultado
        
        if (((ano%4 == 0) && (ano%100 != 0)) || (ano%400 == 0)) {
            System.out.println("O ano " + ano + " é bisiesto");
        } else {
            System.out.println("O ano " + ano + " NON é bisiesto");
        }
    }
    
}
