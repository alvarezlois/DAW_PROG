/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROG02_Ejer06;

import java.util.Scanner;

/**
 *
 * @author adrian
 */
public class PROG02_Ejer06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      /*
        Ei de confesar que este exercicio trabouseme un pouco porque teño JS moi 
        metido dentro e sen traballar con strings ou arrays non se me ocorría como
        encaralo. 
        Vin nun manual online que o truco está en que como a variable numero que 
        o usuario introduce por teclado é un int se o dividimos por 10 e nos quedamos
        co resto sucesivamente teremos no valor do resto a cifra dende a última posición
        ata a primeira
        */
        
        // creamos unha serie de variable int para o número e as posicións de cada cifra
        int numero, primeiro, segundo, terceiro, cuarto, quinto;
        
        // pedimos que o usuario meta un número de 5 díxitos
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce un número de 5 cifras: ");
        numero = sc.nextInt(); // temos aquí o número que nos deu o usuario
        
        // agora comezamos a dividir o numero por 10 e a ver o resto
        quinto = numero%10;
        
        numero /= 10; 
        cuarto = numero%10;
        
        numero /= 10;
        terceiro = numero%10;
        
        numero /= 10;
        segundo = numero%10;
        
        numero /= 10;
        //primeiro = numero%10; 
        primeiro = numero;
        
        // imprimo o resultado
        System.out.print("Os numeros separados son: ");
        System.out.println(primeiro + " " + segundo + " " + terceiro + " " + cuarto + " " + quinto);
    }
    
}
