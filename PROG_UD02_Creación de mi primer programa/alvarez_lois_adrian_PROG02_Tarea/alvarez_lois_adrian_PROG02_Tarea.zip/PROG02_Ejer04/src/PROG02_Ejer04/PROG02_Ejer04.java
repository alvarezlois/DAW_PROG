/*
4. Escribe un programa en Java que pida una nota numérica de 0 a 10 por teclado y 
diga si es un SUSPENSO, APROBADO, BIEN, NOTABLE, SOBRESALIENTE O MATRICULA. 
Teniendo en cuenta la una matrícula es un 10.
 */
package PROG02_Ejer04;
import java.util.Scanner;
/**
 *
 * @author adrian
 */
public class PROG02_Ejer04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // creamos unha variable nota de tipo int
        int nota;
        
        // pedimos por teclado o valor da nota
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce o valor da nota: ");
        nota = sc.nextInt();
        
        // Agora por medio de conficionais mostramos a calificación
        if (0 <= nota && nota < 5) {
        System.out.println("SUSPENSO");
        } else if (5 <= nota && nota < 6) {
            System.out.println("APROBADO");  
        } else if (nota == 6) {
            System.out.println("BEN");
        } else if (nota == 7 || nota == 8) {
            System.out.println("NOTABLE");
        } else if (nota == 9) {
            System.out.println("SOBRESALIENTE");
        } else if (nota == 10) {
            System.out.println("MATRÍCULA DE HONOR");
        }
            
        
    
    }   
}