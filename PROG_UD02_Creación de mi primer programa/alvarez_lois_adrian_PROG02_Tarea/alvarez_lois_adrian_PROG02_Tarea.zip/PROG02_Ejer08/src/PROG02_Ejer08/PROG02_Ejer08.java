/*
 8. Escriba un programa que lea la entrada de una hora de un día en notación 20 
horas y la muestre en notación de 12 horas. Por ejemplo, si introducimos 18:05 
debe proporcionar como salida 06:05 PM. Úsese un operador condicional/ternario (? :).
 */
package PROG02_Ejer08;
import java.util.Scanner;
/**
 *
 * @author adrian
 */
public class PROG02_Ejer08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int horaVella, horaNova, minutos, meridiano, resta;
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce a hora en formato 24h: ");
        horaVella = sc.nextInt();
        System.out.print("Introduce os minutos: ");
        minutos = sc.nextInt();
        
        resta = horaVella - 12;
        
        if ((resta < 0) || (resta == 12)) {
        horaNova = resta < 12 ? horaVella : 12;
        meridiano = 1;
        } else {
        horaNova = resta == 0 ? horaVella : resta; 
        meridiano = 2;
        }
        
        switch (meridiano){
            case 1:
                if (horaNova < 10){
                    if (minutos < 10) {
                    System.out.println("Nova Hora: 0" + horaNova + ":0" + minutos + " AM");
                    } else {
                    System.out.println("Nova Hora: 0" + horaNova + ":" + minutos + " AM");
                    }
                } else {
                    if (minutos < 10) {
                    System.out.println("Nova Hora: " + horaNova + ":0" + minutos + " AM");
                    } else {
                    System.out.println("Nova Hora: " + horaNova + ":" + minutos + " AM");
                    }
                } 
                
                break;
                
            case 2:
               if (horaNova < 10){
                    if (minutos < 10) {
                    System.out.println("Nova Hora: 0" + horaNova + ":0" + minutos + " PM");
                    } else {
                    System.out.println("Nova Hora: 0" + horaNova + ":" + minutos + " PM");
                    }
                } else {
                    if (minutos < 10) {
                    System.out.println("Nova Hora: " + horaNova + ":0" + minutos + " PM");
                    } else {
                    System.out.println("Nova Hora: " + horaNova + ":" + minutos + " PM");
                    }
                } 
                break;
                
        }
        
    }
    
}
