
package net.sanclemente.cifraseletras;

import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

import net.sanclemente.cifraseletras.base.*;


/**
 *
 * @author adrian alvarez lois
 */
public class AppCifrasELetras {

    
// Atributo estático:
    static Scanner sc = new Scanner(System.in);
    
// método estatico menu(): muestra el menú y devuelve el carácter pulsado por el usuario.
    public static String menu(){
    System.out.println("\n");
    System.out.println("a) Pedir letras.");
    System.out.println("b) Mostrar letras.");
    System.out.println("c) Comprobar palabra.");
    System.out.println("d) Generar números.");
    System.out.println("e) Mostrar números.");
    System.out.println("f) Comprobar cifras.");
    System.out.println("s) Salir.");
    System.out.print("\nESCOJA UNA OPCIÓN: ");
    
    String opcion = sc.nextLine().toLowerCase(); // almacena la letra que el usuario teclea
    System.out.println("Has escogido la opción: " + opcion);
    return opcion;
    }

    
    public static void main(String[] args) {
    // creamos los objetos cifras y letras. Los constructores por defecto no me van
    //public  Cifras cifras = new Cifras();
    //Letras letras = new Letras();
    Letras letras = new Letras("Letras", 9);
    Cifras cifras = new Cifras("Cifras", 6, 234);
    int gameOver = 0;
    do{
    String select = menu();     

        switch (select){
            case "a":
                 letras.setLetras();
                break;
                
            case "b":
                System.out.println("Las letras generadas son: " + Arrays.toString(letras.getLetras()));
                break;
                
            case "c":
                boolean comprobacionPalabra;
                System.out.print("Dame una palabra: ");
                String palabra = sc.nextLine(); // almaceno la palabra que se introduce por teclado
                palabra = palabra.toLowerCase(); // paso las letras a minúsculas
                comprobacionPalabra = letras.comprobar(palabra);
                if (comprobacionPalabra){
                System.out.println("La palabra SÍ es correcta.");
                } else {
                    if (!comprobacionPalabra){
                    System.out.println("La palabra NO es correcta.");
                    }
                 }
                break;
                
            case "d":
                cifras.setCifras();
                break;
                
            case "e":
                System.out.println("He generado una lista de números aleatorios: " + Arrays.toString(cifras.getCifras()));
                break;
                
            case "f": // NO SOY CAPAZ DE HACER QUE ESTO FUNCIONE!!!!!
                //int arrayInt[] = new int[6];
                ArrayList<String> enteros = new ArrayList<>();
                boolean encontrado;
                int i;
                for (i = 0; i < 6; i++){
                System.out.print("Teclea una cifra: "); 
                String entrada = sc.nextLine();// es el dato a buscar
                enteros.add(entrada);
                //System.out.println("Mi ArrayInt: " + Arrays.toString(arrayInt));
                //System.out.println("Array Cifras: " + Arrays.toString(cifras.getCifras()));
                encontrado = cifras.comprobar(enteros); // devuelve true o false
                    if (encontrado){
                    System.out.println("Bien! tu cifra está en la lista."); // imprimo mensaje de éxito
                    } else{
                        if (!encontrado){
                        System.out.println("UPS! tu cifra NO está en la lista."); // imprimo mensaje de éxito
                        }
                    }
                }
               break;
            
            case "s":
                System.out.println("GAME OVER");
                gameOver = 1;
                break;
                
        }
    } while (gameOver == 0);
  } 
}
