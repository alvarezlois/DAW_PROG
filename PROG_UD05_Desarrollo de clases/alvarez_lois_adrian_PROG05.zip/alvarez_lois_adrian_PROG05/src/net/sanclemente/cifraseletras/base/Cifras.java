package net.sanclemente.cifraseletras.base;
import java.util.Arrays;
import java.util.ArrayList;
/**
 *
 * @author adrian alvarez lois
 */
public final class Cifras extends XogoAzar implements Comprobable {
    
    /*** Constantes ***/
    // número de cifras aleatorias a generar.
    public final int NUM_CIFRAS = 6;
    // máximo valor que puede tomar cada cifra de la lista, generadas aleatoriamente
    public final int MAX_CIFRA = 10;
    // valor mínimo que puede tener el número de resultado generado aleatoriamente.
    public final int MIN_RESULTADO = 100;
    // valor máximo que puede tener el número de resultado generado aleatoriamente.
    public final int MAX_RESULTADO = 1000;
    
    /*** Atributos ***/
    // array con los números enteros del juego.
    int[] cifras = new int[0];
    // número que debe calcular el concursante.
    int resultado;

   
    /* CONSTRUCTORES */

    // constructor que recoge el resultado a obtener
    public Cifras(String nome,int resul){
       super(nome); //constructor de XogoAzar
       this.nome = "Cifras";
       this.resultado = resul;
       cifras = new int[NUM_CIFRAS];
       
    }
    // constructor que recoge el número máximo de cifras y el resultado
    public Cifras (String nome, int maxCifras, int resul){
        super(nome); //constructor de XogoAzar
        this.nome = "Cifras";
        this.resultado = resul;
        cifras = new int[maxCifras];
    }
  /*  // constructor por defecto
    @Override
    public void setXogo(String nome){
        this.nome = "Cifras";
        //super.XogoAzar("Cifras");
        //super.getXogo();
        //super.setXogo("Cifras");
        this.resultado = setResultado();
    }
    public Cifras(){
        super(nome);
    super.getXogo();
    }*/
    
    /* MÉTODOS */
    
    // método get para el atributo cifras
     public  int[] getCifras(){
     return cifras;
     }
     
// método set para el atributo cifras
     final public void setCifras(int cifraEngadida){
         for (int i = 0; i < cifras.length; i++){// recorre el array y pone la letraEngadida en la posición que esté vacía
            if (Character.isSpaceChar(cifras[i])){ // si la letra de la posicion i está vacía 
            cifras[i] = cifraEngadida; // añadimos esa a esa posición nuestra letraEngadida
            }
         }
     }
     
// método setResultado()
      public int setResultado(){
        int intAleatorio = XERADOR.nextInt(MAX_RESULTADO); // número aleatorio entre 0 y MAX_RESULTADO
        this.resultado = (intAleatorio - MIN_RESULTADO) - MIN_RESULTADO;
        return this.resultado;
     }
     
// addCifra(): recoge un numero y devuelve verdadero o falso, dependiendo
// de si pudo añadirla o no. Para eso debe recorrer el array en busca de
// un espacio vacío para poner la letra en esa posición.
     public boolean addCifra(int cifraEngadida) {
        boolean exito = false;
        int posicion = 0;
        for (int i = 0; i < cifras.length; i++) { // busca un espacio vacío
            if (cifras[i] == '\u0000') { // true si cifras[i] es un espacio en blanco 
                posicion = i; // nos quedamos con la posición vacía que ha encontrado
                exito = true; // si hay posición vacía tendremos éxito al insertar la cifra
            }
        }
        cifras[posicion] = cifraEngadida; // añado la cifra a la posición vacía que ha encontrado
        
    return (exito); // devuelvo el resultado true o false si he tenido éxito o no al introducir la cifra.
    }
    
     
// método seguinte() genera un número aleatorio entre 1 y MAX_CIFRA.
     public int seguinte(){
     int numeroAleatorio = XERADOR.nextInt((MAX_CIFRA-1)+1);
     return (numeroAleatorio);
     }
     
// método setCifras(). no recoge ningún parámetro. Este método debe generar los n números
// (tamaño del array) de modo aleatorio, generando en cada iteración un
// número aleatorio por medio de una llamada al método seguinte().
      public void setCifras(){
        for (int i = 0; i < cifras.length; i++){
             cifras[i] = seguinte();
        }
     }
     
// comprobar: implantación del método de la interface.
      
      public boolean comprobar(ArrayList<String> lista){
        boolean comprobacion = false;
        //int m = 0;
      String cadenaCifras = Arrays.toString(cifras);
      //String cadenaInt = lista.get(i);
      int i = lista.size()-1;
         String num = lista.get(i);
         if (cadenaCifras.indexOf(num) > 0){
         //System.out.print("Bien. " + num + " está en las cifras");
         comprobacion = true;
         }
      return comprobacion;}
    /*
        ArrayList<Integer> cifrasList = new ArrayList(); // Declaración el ArrayList
        for(int x = 0; x < cifras.length; x++){ // lleno el arraylist con los números de cifras
        cifrasList.add(cifras[x]);              // recorriendo el array cifras
        }
        
        for (int i = 0; i < arrayEnteros.length; i++){ // recorro el array pasado por parametro
            if (cifrasList.contains(arrayEnteros[i])){ // si contiene el elemento del array pasado por parametro = true
            comprobacion = true;
            }
        }
        */
        /*
        for (int i = 0; i < arrayInt.length; i++){ 
            int pos = Arrays.binarySearch(cifras, arrayInt[i]);
            if (pos >= 0){
            comprobacion = true;
            }
        }
        */
     
     
    
// toString: método sobrescrito de XogoAzar que devuelve la cadena
// (String) con la lista de letras en mayúscula separadas por una barra
// vertical (|).
     @Override
    public String toString(){ // IMPORTANTE siempre utilizar public
      
        StringBuilder cadena = new StringBuilder(); // creo el StringBuilder a partir de cifrasCadena
        // En cada iteración añadimos a la cadena el valor leído del array letras con el mñétodo append de StringBuilder
        for (int i = 0; i <= cifras.length; i++){
          cadena = cadena.append(cifras[i]);  
        }
        // Añado el caracter | cada 2 posiciones a partir de la 1 y hasta el tamaño de la cadena -1
        int posicion = 1;
        while(posicion <= (cadena.length())-1){
            cadena = cadena.insert(posicion, '|'); // utilizo el método insert del StringBuilder
            posicion += 2;
        }
       // Convierto el StringBuilder en un String
       String cifrasCadena = cadena.toString();
       // mensaje con el resultado
       String mens;
       mens = "Resultado: " + this.resultado;
       // devuelvo cifrasCadena y el mensaje
        return (cifrasCadena + mens);
    }

    @Override
    public boolean comporbar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
  
} // final de la clase
