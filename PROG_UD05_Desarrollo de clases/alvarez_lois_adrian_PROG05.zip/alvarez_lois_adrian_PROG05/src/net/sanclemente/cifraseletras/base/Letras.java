package net.sanclemente.cifraseletras.base;

import java.util.Scanner;

/**
 *
 * @author adrian alvarez lois
 */
public final class Letras extends XogoAzar implements Comprobable{
// Atributo para recoger info por teclado
      static Scanner teclado = new Scanner(System.in);
// String con las vocales del abecedario
      public static final String VOCAIS = "aeiou";
// String con las consonantes del abecedario
      public static final String CONSONANTES = "bcdfghjklmnñpqrstvwxyz";
// Número de letras que tiene el juego
      public static final int NUM_LETRAS = 9;
// Atributo letras. Array de caracteres con las letras del juego
      char [] letras = new char[0];
     
// constructor por defecto
    /*
      public Letras(){
        super.setXogo("Letras");
        letras = new char[NUM_LETRAS];
    } 
    */
     
// Constructor al que se le pasa nombre y numero de letras del juego   
    public Letras(String nome, int NUM_LETRAS) {
        super(nome); // Constructor de la superclase
        letras = new char[NUM_LETRAS];// Array del tamaño del número máximo de letras pasado
        //Arrays.fill(letras,' '); // lleno el array de espacios en blanco
        this.nome = "Letras"; // Asigna el nombre con el valor "Letras"
    }
    
     
// método get para el atributo letras
     public char[] getLetras(){
     return (letras);
     }
     
// método set para el atributo letras
     public void setLetras(char letraEngadida){
         for (int i = 0; i < letras.length; i++){// recorre el array y pone la letraEngadida en la posición que esté vacía
            if (letras[i] == '\u0000'){ // si la letra de la posicion i está vacía o sea con un guión -
            letras[i] = letraEngadida; // añadimos esa a esa posición nuestra letraEngadida
            }
         }
     }
     
// getTamanho(): devuelve el tamaño del array (número de letras que puede guardar)
     public int getTamanho(){
     int tamanho = letras.length;
     return (tamanho);
     }
     
// getNumLetras(): devuelve el número de letras (piensa que puede haber casillas vacías) que tiene el array.
     public int getNumLetras(){
        int numLetras = 0; // recoge la cantidad de letras
        for (int i = 0; i <= letras.length; i++){  // recorremos el array y
            if (letras[i] != '\u0000') { //  si una posición tiene un caracter (NO vacío) 
            numLetras++;                // le suma 1 a la variable que cuenta las letras
            }
        }
        return numLetras;
     }
     
// addLetra(): recoge una letra y devuelve verdadero o falso, dependiendo
// de si pudo añadirla o no. Para eso debe recorrer el array en busca de
// un espacio vacío para poner la letra en esa posición.
    public boolean addLetra(char letraEngadida) {
        boolean exito = false;
        int posicion = 0;
        for (int i = 0; i < letras.length; i++) { // busca un espacio vacío
            if (letras[i] == '\u0000') { // true si letras[i] es un espacio en blanco (letras[i] == '\u0000')
                posicion = i; // nos quedamos con la posición vacía que ha encontrado
                exito = true; // si hay posición vacía tendremos éxito al insertar la letra
            }
        }
        letras[posicion] = letraEngadida; // añado la letra a la posición vacía que ha encontrado
        
    return (exito); // devuelvo el resultado true o false si he tenido éxito o no al introducir la letra.
    }
     
    
// getVocal(): método estático que devuelve una vocal aleatoria.
// Recuerda que el objeto XERADOR (de tipo Random) tiene un método
// nextInt/(max) que devuelve un número aleatorio entre 0 y max-1.
    public static char getVocal(){
        int intAleatorio = XERADOR.nextInt(VOCAIS.length()-1);// Producir nuevo int aleatorio entre 0 y longitud del array VOCAIS
        char vocalAleatoria = VOCAIS.charAt(intAleatorio); // cojo una letra del caracter nº aleatorio del array VOCAIS
        return (vocalAleatoria); // TENEMOS QUE TENER SIEMPRE LA VARIABLE INICIADA!!!!!!
    }
    
// getConsoante(): método estático que devuelve una consonante
// aleatoria. Igual al anterior sólo que con consonantes.
    public static char getConsonante(){
        int intAleatorio = XERADOR.nextInt(CONSONANTES.length()-1);
        char consAleatoria = CONSONANTES.charAt(intAleatorio);
        return (consAleatoria);
    }
    
// setLetras(): método sobrecargado del definido anteriormente que no recoge ningún parámetro.
    
    
    
    public void setLetras(){
        
        for (int w = 0; w < NUM_LETRAS; w++){ // bucle con iteraciones hasta 9
        char vocal, consonante;
        System.out.print("quieres vocal (v) o consonante (c): ");
        char opcion = teclado.nextLine().toLowerCase().charAt(0); // almacenamos la opcion del jugador que entra por teclado
        String decision = "vc";
            if (opcion == decision.charAt(0)){ //opcion == v -> vocales
                vocal = getVocal();
                addLetra(vocal);
            } else {
                if (opcion == decision.charAt(1)){ //opcion == c -> consonantes
                consonante = getConsonante();
                addLetra(consonante);
                }
            }
        }
    }

    
    
// comprobar: implantación del método de la interface.
    public boolean comprobar(String palabra){
       boolean comprobacion = false;
       // pasamos el array letras a string
       String cadLetras = String.valueOf(letras);
       for(int i = 0; i < palabra.length(); i++){
           char caracter = palabra.charAt(i);
           for (int j =0; j < cadLetras.length(); j++){
               if (palabra.charAt(i) == cadLetras.charAt(j)){
                   comprobacion = true;
                   char zero = cadLetras.charAt(j);
                   zero = '0';
                   break;
               }
           }
        }
    return comprobacion;
    }
    
    
// toString: método sobrescrito de XogoAzar que devuelve la cadena
// (String) con la lista de letras en mayúscula separadas por una barra
// vertical (|).
     @Override
    public String toString(){ // IMPORTANTE siempre utilizar public
       StringBuilder cadena = new StringBuilder(); // creo el StringBuilder a partir de letrasCadena
        // En cada iteración añadimos a la cadena el valor leído del array letras con el mñétodo append de StringBuilder
        for (int i = 0; i <= letras.length; i++){
          cadena = cadena.append(letras[i]);  
        }
        // Añado el caracter | cada 2 posiciones a partir de la 1 y hasta el tamaño de la cadena -1
        int posicion = 1;
        while(posicion <= (cadena.length())-1){
            cadena = cadena.insert(posicion, '|'); // utilizo el método insert del StringBuilder
            posicion += 2;
        }
        // Convierto el StringBuilder en un String
        String letrasCadena = cadena.toString();
        // Paso las letras a Mayúscula
        letrasCadena = letrasCadena.toUpperCase();
        // Devuelvo el valor de la cadena final
        return letrasCadena;
    }

// Esto no tengo ni idea para que está aquí...
    @Override
    public boolean comporbar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

      
} // final de la clase

