package net.sanclemente.cifraseletras.base;

import java.util.Random;
/**
 *
 * @author adrian alvarez lois
 */
public abstract class XogoAzar {
    //creamos el objecto XERADOR que nos genera números aleatorios
    public static final Random XERADOR = new Random();
    
    //creamos el atributo nome: nombre del juego. Por ejemplo, “Cifras”
    public String nome;
    
    //creamos un constructor que recoge el nombre y lo asigna al atributo nome
    XogoAzar(String nome){
    this.nome = nome;
    }
    
    //Métodos get/set para el atributo nome.
    // getter
    public String getXogo(){
    return this.nome;
    }
    // setter
    public void setXogo(String nomeXogo){
    this.nome = nomeXogo;
    
    }
    
    //Sobrescribe el método toString() de Object para que devuelva el
    //nombre del juego en mayúsculas.
    @Override
    public String toString(){
    String mensaxe = this.nome;
    return mensaxe.toUpperCase();
    }

   
}
