package net.sanclemente.cifraseletras.base;

/**
 *
 * @author adrian alvarez lois
 */
public interface Comprobable {
    /*
    La interface Comprobable en el paquete net.sanclemente.cifraseletras.base,
    debe tener:
    Método: comprobar, recoge un objeto y devuelve verdadero cuando el objeto sea
    correcto. Recuerda, forma parte de una interface, que no se implanta.
    */
    
    public boolean comporbar();
            
    
    
}
